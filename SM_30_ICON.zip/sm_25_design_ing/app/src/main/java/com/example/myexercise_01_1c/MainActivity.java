package com.example.myexercise_01_1c;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.RelativeLayout;

import com.amitshekhar.DebugDB;
import com.example.myexercise_01.R;
import com.example.myexercise_01_1c.db.AlarmCursorAdapter;
import com.example.myexercise_01_1c.db.DBHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

//알람 목록 액티비티
public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
    private static final int PERMISSION_REQUEST_CODE = 1;
    private static final String TAG = MainActivity.class.getSimpleName();
    private static final int OVERLAY_PERMISSION_REQ_CODE = 500;
    //static int flag = 0;
    ListView listView;
    DBHelper dbHelper;
    AlarmCursorAdapter cursorAdapter;
    RelativeLayout floatingActionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setToolbar();
        init(); //초기화 작업
        DebugDB.getAddressLog();    //Open http://192.168.1.44:8080 in your browser
        checkPermission(); //다른앱 위에 그리기 권한 있는지 확인
    }
    /* start of 다른앱위에 그리기 권한 */
    private void checkPermission() {
        if (!Settings.canDrawOverlays(getApplicationContext())) showDialog(); //다른앱위에 그리기 권한이 없을때만 실행
    }
    private void setToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar); // 내 툴바를 액티비티의 앱바로 설정
        getSupportActionBar().setTitle("");
    }
    void showDialog() {
        AlertDialog.Builder msgBuilder = new AlertDialog.Builder(MainActivity.this)
                .setTitle("다른 앱 위에 표시 권한을 설정해주십시오")
                .setMessage("권한 설정하러 가기")
                .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        requestPermissions();
                    }
                }).setNegativeButton("취소", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialogInterface, int i) {
                    }
                });
        AlertDialog msgDlg = msgBuilder.create();
        msgDlg.show();
    }
    private void requestPermissions() {
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
        startActivityForResult(intent, OVERLAY_PERMISSION_REQ_CODE);
    }
    /* end of 다른앱위에 그리기 권한 */

    private void init() {
        listView = findViewById(R.id.listView);
        floatingActionButton = findViewById(R.id.fab);

        dbHelper = DBHelper.getInstance(this);

        cursorAdapter = new AlarmCursorAdapter(getApplicationContext(), dbHelper.getCursorInSort(), false);
        listView.setAdapter(cursorAdapter);

        // 리스트 뷰의 각각의 아이템을 클릭했을 때의 리스너 입니다.
        listView.setOnItemClickListener(this);
    }


    public void onClickFAButton(View view) {
        Intent intent = new Intent(this, AlarmSettingActivity.class);
        intent.putExtra("setting", 0);
        startActivityForResult(intent, 0);
    }

    @Override     // startActivityForResult로 다른 액티비티 갔다가 다시 이 액티비티로 돌아왔을 때 자동 호출되는 메소드
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        cursorAdapter.changeCursor(dbHelper.getCursorInSort()); //DB값 변동됐으니 리스트뷰도 업데이트
    }

    // 리스트 뷰의 각각의 아이템을 클릭했을 때의 리스너 입니다.
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Log.d("zzmain", String.valueOf(view.getId()));
        Log.d("zzmain, position", String.valueOf(position));

        Cursor cursor = (Cursor) cursorAdapter.getItem(position);
        long ID = cursor.getLong(cursor.getColumnIndex("_id"));
        Log.d("zzmain, id", String.valueOf(ID));

//            dbHelper.changeEnable(ID, false);

        long time = cursor.getLong(cursor.getColumnIndex("TIME"));
        Intent intent = new Intent(MainActivity.this, AlarmSettingActivity.class);
//        intent.putExtra("cursor", (Serializable) cursor); //sqlite.SQLiteCursor cannot be cast to java.io.Serializable

        intent.putExtra("setting", 1);
        intent.putExtra("id", ID);
        intent.putExtra("time", time);
        startActivityForResult(intent, 1);

    }

}
/** END OF CODE **/
//        setSupportActionBar((Toolbar) findViewById(R.id.my_toolbar)); //툴바 상단에 설정
//    // 리스트 뷰의 각각의 아이템을 클릭했을 때의 리스너 입니다.
//    @Override
//    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//        Log.d("zzz", "z");
////                AlarmModel clickedAlarm = (AlarmModel) parent.getItemAtPosition(position);
////                AlarmModel clickedAlarm = (AlarmModel) alarmAdapter.getItem(position);
////                Log.d("zz", Integer.toString(clickedAlarm.getID()));;
////                dbHelper.deleteAlarm(clickedAlarm);
////                dbHelper.deleteIdAlarm(clickedAlarm.getID());
//        ShowAlarmOnListView();
////                Toast.makeText(MainActivity.this, "deleted " + clickedAlarm.toString(), Toast.LENGTH_SHORT).show();
//
//        Cursor cursor = (Cursor) cursorAdapter.getItem(position);
////                String index = cursor.getString(cursor.getColumnIndex("_id"));
//        int ID = cursor.getInt(cursor.getColumnIndex("_id"));
//        long time = cursor.getLong(cursor.getColumnIndex("TIME"));
////                dbHelper.deleteIdAlarm(ID);
//
//        Intent intent = new Intent(MainActivity.this, AlarmSettingActivity.class);
//        intent.putExtra("setting", 1);
//        intent.putExtra("id", ID);
//        intent.putExtra("time", time);
//        startActivityForResult(intent, 1);
//
////                int ID = Integer.parseInt(index);
//
////                List<AlarmModel> alarmList = dbHelper.getAlarmList() ;
////                AlarmModel alarm = alarmList.get(position);
//
////                intent.putExtra("id", id);
////                startActivityForResult(intent, 0);
//        ShowAlarmOnListView();
//    }