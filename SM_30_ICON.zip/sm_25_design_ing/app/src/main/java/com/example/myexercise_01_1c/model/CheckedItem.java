package com.example.myexercise_01_1c.model;

public class CheckedItem {
    public boolean checked;
    long id;
    public int position;

    public CheckedItem(long id, int position, boolean checked) {
        this.id = id;
        this.position = position;
        this.checked = checked;
    }
    public CheckedItem() {}
    public CheckedItem(long id, boolean checked) {
        this.id = id;
        this.position = position;
        this.checked = checked;
    }
}
