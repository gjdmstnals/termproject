package com.example.myexercise_01_1c.model;

import android.content.Intent;
import android.net.Uri;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.BitSet;
import java.util.Comparator;

public class Alarm implements Serializable {
    private static final long serialVersionUID = 1L;

    private int COUNT, VOLUME;
    private long ID, TIME;
    private boolean MON, TUE, WED, THU, FRI, SAT, SUN, ENABLE;
    private String NAME, WORKOUT;
    private String MUSIC; //기존값

    public static void putAlarm(Intent intent, Alarm alarm) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream out = null;
        try {
            out = new ObjectOutputStream(bos);
            out.writeObject(alarm);
            out.flush();
            byte[] data = bos.toByteArray();
            intent.putExtra("alarm", data);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                bos.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static Alarm getAlarm(Intent intent) {
        ByteArrayInputStream bis = new ByteArrayInputStream(intent.getByteArrayExtra("alarm"));
        ObjectInput in = null;
        Alarm alarm = null;
        try {
            in = new ObjectInputStream(bis);
            alarm = (Alarm)in.readObject();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        return alarm;
    }

    public Alarm(long _id, long TIME, boolean MON, boolean TUE, boolean WED, boolean THU, boolean FRI, boolean SAT, boolean SUN, String NAME, String EXER, int COUNT, String MUSIC, int VOLUME) {
        this.ID = _id;
        this.TIME = TIME;
        this.MON = MON;
        this.TUE = TUE;
        this.WED = WED;
        this.THU = THU;
        this.FRI = FRI;
        this.SAT = SAT;
        this.SUN = SUN;
        this.NAME = NAME;
        this.WORKOUT = EXER;
        this.COUNT = COUNT;
        this.MUSIC = MUSIC;
        this.VOLUME = VOLUME;
    }
    //전부다 저장
    public Alarm(long _id, long TIME, BitSet dayBitset, String NAME, String WORKOUT, int COUNT, String MUSIC, int VOLUME, boolean ENABLE) {
        this.ID = _id;
        this.TIME = TIME;
        this.MON = dayBitset.get(0);
        this.TUE = dayBitset.get(1);
        this.WED = dayBitset.get(2);
        this.THU = dayBitset.get(3);
        this.FRI = dayBitset.get(4);
        this.SAT = dayBitset.get(5);
        this.SUN = dayBitset.get(6);
        this.NAME = NAME;
        this.WORKOUT = WORKOUT;
        this.COUNT = COUNT;
        this.MUSIC = MUSIC;
        this.VOLUME = VOLUME;
        this.ENABLE = ENABLE;
    }
    //쓰지마셈
//    public Alarm(long TIME, BitSet dayBitset, String NAME, String WORKOUT, int COUNT, Uri MUSIC, int VOLUME) {
//        this.TIME = TIME;
//        this.MON = dayBitset.get(0);
//        this.TUE = dayBitset.get(1);
//        this.WED = dayBitset.get(2);
//        this.THU = dayBitset.get(3);
//        this.FRI = dayBitset.get(4);
//        this.SAT = dayBitset.get(5);
//        this.SUN = dayBitset.get(6);
//        this.NAME = NAME;
//        this.WORKOUT = WORKOUT;
//        this.COUNT = COUNT;
//        this.MUSIC = MUSIC;
//        this.VOLUME = VOLUME;
//    }
    //id는 저장안하는 알람 모델 생성자, id는 DB에서 자동생성된 id값 쓰려고함
    public Alarm(long TIME, BitSet dayBitset, String NAME, String WORKOUT, int COUNT, String MUSIC, int VOLUME, boolean ENABLE) {
        this.TIME = TIME;
        this.MON = dayBitset.get(0);
        this.TUE = dayBitset.get(1);
        this.WED = dayBitset.get(2);
        this.THU = dayBitset.get(3);
        this.FRI = dayBitset.get(4);
        this.SAT = dayBitset.get(5);
        this.SUN = dayBitset.get(6);
        this.NAME = NAME;
        this.WORKOUT = WORKOUT;
        this.COUNT = COUNT;
        this.MUSIC = MUSIC;
        this.VOLUME = VOLUME;
        this.ENABLE = ENABLE;
    }
    public int getRequestCode() {   //알람매니저 서비스에 등록할 때 필요한 request code로 사용하려고
        final long id = getID();
        return (int) (id^(id>>>32));    //long을 int의 hashcode로 바꾸는 코드
    }

    public void setID(long id) {   //알람매니저 서비스에 등록할 때 필요한 request code로 사용하려고
        ID = id;
    }

    public Alarm() {
    }

    @Override
    public String toString() {
        return "AlarmModel{" +
                "ID =" + ID +
                ", TIME =" + TIME +
                ", MON =" + MON +
                ", TUE =" + TUE +
                ", WED =" + WED +
                ", THU =" + THU +
                ", FRI =" + FRI +
                ", SAT =" + SAT +
                ", SUN =" + SUN +
                ", NAME =" + NAME +
                ", WORKOUT =" + WORKOUT +
                ", COUNT =" + COUNT +
                ", MUSIC =" + MUSIC +
                ", VOLUME =" + VOLUME +
                ", ENABLE = " + ENABLE +
                '}';
    }
//    public AlarmModel getAlarmModelById(int _id) {
//
//    }

    public long getID() { return ID; }

    public long getTIME() { return TIME; } //miliis값 설정 ..

    public void setTIME(long TIME) { this.TIME=TIME; }

    public boolean getMON() {
        return MON;
    }

    public void setMON(boolean MON) {
        this.MON = MON;
    }

    public boolean getTUE() {
        return TUE;
    }

    public void setTUE(boolean TUE) {
        this.TUE = TUE;
    }

    public boolean getWED() {
        return WED;
    }

    public void setWED(boolean WED) {
        this.WED = WED;
    }

    public boolean getTHU() {
        return THU;
    }

    public void setTHU(boolean THU) {
        this.THU = THU;
    }

    public boolean getFRI() {
        return FRI;
    }

    public void setFRI(boolean FRI) {
        this.FRI = FRI;
    }

    public boolean getSAT() {
        return SAT;
    }

    public void setSAT(boolean SAT) {
        this.SAT = SAT;
    }
    public boolean getSUN() {
        return SUN;
    }

    public void setSUN(boolean SUN) {
        this.SUN = SUN;
    }

    public String getNAME() { return NAME; }

    public String getWORKOUT() { return WORKOUT; }

    public int getCOUNT() { return COUNT; }

    public String getMUSIC() { return MUSIC; }

    public int getVOLUME() { return VOLUME; }

    public boolean getENABLE() { return ENABLE; }

//    Comparator<>
}
