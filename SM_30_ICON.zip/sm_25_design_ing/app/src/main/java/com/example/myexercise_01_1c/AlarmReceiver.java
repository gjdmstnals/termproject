package com.example.myexercise_01_1c;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.widget.Toast;

import com.example.myexercise_01_1c.db.DBHelper;
import com.example.myexercise_01_1c.model.Alarm;
import com.example.myexercise_01_1c.util.TimeUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.util.Calendar;

import static android.app.PendingIntent.FLAG_UPDATE_CURRENT;

public class AlarmReceiver extends BroadcastReceiver {
    Context context;
    static String TAG = "클래스AlarmReceiver";
//    static int flag = 0;
    //방송이 수신되면 자동으로 호출되는 콜백메서드, 각 방송 정보는 intent로 전달됨 Intent
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(getClass().getSimpleName(), "onReceive");

        Alarm alarm = Alarm.getAlarm(intent); //pendingindent.getBroadcast에 커스텀 객체 전달할 경우 byte로 받아야함
        Log.d(TAG, String.valueOf(alarm));

        //디버깅용
        String str2 = "알람onReceive: " + alarm.getTIME();
        Log.d(TAG, str2);

        registerAlarm(context, alarm); // 알람 재등록
        //디버깅용
//        boolean week[] = {false, intent.getBooleanExtra("sun", true), alarm.getMON(),
//                intent.getBooleanExtra("tue", true), intent.getBooleanExtra("wed", true),
//                intent.getBooleanExtra("thu", true), intent.getBooleanExtra("fri", true),
//                intent.getBooleanExtra("sat", true)};
        boolean week[] = {false, alarm.getSUN(), alarm.getMON(), alarm.getTUE(), alarm.getWED(), alarm.getTHU(), alarm.getFRI(), alarm.getSAT()};
        Calendar cal = Calendar.getInstance();
        if (!week[cal.get(Calendar.DAY_OF_WEEK)]) {
            return;
        }
        Toast.makeText(context, str2, Toast.LENGTH_SHORT).show();

//        if (flag==1) return;

//        //Alarm Ringing Activity 수행
        Intent i = new Intent(context, AlarmRingingActivity.class);
        i.putExtra("alarm", alarm); //액티비티간의 전달은 그냥 putExtra로 전달
//        Alarm.putAlarm(i, alarm);

        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
//        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK); //는 안되더라
//        i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP |Intent.FLAG_ACTIVITY_NEW_TASK |Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);


        context.startActivity(i);
    }

    public static void cancelAlarm(Context context, Alarm alarm) {
        final Intent intent = new Intent(context, AlarmReceiver.class);
        final PendingIntent pIntent = PendingIntent.getBroadcast(
                context, alarm.getRequestCode(), intent, FLAG_UPDATE_CURRENT);

        final AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Toast.makeText(context, "알람이 해지되었습니다", Toast.LENGTH_SHORT).show();
        manager.cancel(pIntent);

        TimeUtils.printTimeStringDebug("알람서비스해지", alarm.getTIME());
    }
    public static void cancelAlarm(Context context, int requestcode) {
        final Intent intent = new Intent(context, AlarmReceiver.class);
        final PendingIntent pIntent = PendingIntent.getBroadcast(
                context, requestcode, intent, FLAG_UPDATE_CURRENT);

        final AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Toast.makeText(context, "알람이 해지되었습니다", Toast.LENGTH_SHORT).show();

        manager.cancel(pIntent);

    }
    public static void registerAlarm(Context context, Alarm alarm) {
        final Intent intent = new Intent(context, AlarmReceiver.class); // Receiver 설정

        if (alarm == null) Log.d(TAG, "등록시 알람널");
        else               Log.d(TAG, "등록시 알람널아님");

        Alarm.putAlarm(intent, alarm); //알람 전송

        //맞추려는 알람이 현재시간보다 미래여야함 !!
        final Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(alarm.getTIME());

        long currentTime = System.currentTimeMillis();
        while (calendar.getTimeInMillis() < currentTime) { //맞추려는 알람이 현재시간 보다 과거일 때 동안
            calendar.add(Calendar.DATE, 1);
            TimeUtils.printTimeStringDebug("registerAlarm 예전시간임", alarm.getTIME(), calendar.getTimeInMillis());
        }
        //DB에 값을 다시 써줘야하나..안써줘도될듯 시간값만 있음 되니까?!!그래도 일단 써주자
        DBHelper dbHelper = DBHelper.getInstance(context);
        dbHelper.changeTime(alarm.getTIME(), calendar.getTimeInMillis()); //DB에 알람시간 업데이트
        alarm.setTIME(calendar.getTimeInMillis()); //alarm객체에 시간 업데이트

        //브로드캐스트 발송하는 펜딩인덴트
        /* receiver를 동작하게 하기 위해 PendingIntent의 인스턴스를 생성할 때, getBroadcast 라는 메소드를 사용함.
        requestCode는 나중에 Alarm을 해제 할때 어떤 Alarm을 해제할지를 식별하는 코드 */
        final PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context, alarm.getRequestCode(), intent, PendingIntent.FLAG_CANCEL_CURRENT);

        final AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        /* 설정된 시각에 알람 설정
        인자 : 알람매니저 타입 / 언제 이 알람이 발동되야하는지 그 시간을 long값으로 줘야함 / 뭐가 실행될지는 펜딩인덴트로 동작하게 함. */
        manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, alarm.getTIME(), pendingIntent); //setExact()과 동일하만 절전모드에서도 동작하는 함수
//        manager.setAlarmClock(new AlarmManager.AlarmClockInfo(alarm.getTIME(), pendingIntent), pendingIntent);

        TimeUtils.printTimeStringDebug("알람서비스등록", alarm.getTIME(), alarm.getRequestCode());
    }
}

