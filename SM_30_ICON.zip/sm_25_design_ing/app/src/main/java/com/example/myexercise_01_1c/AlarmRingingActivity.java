package com.example.myexercise_01_1c;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;
import com.example.myexercise_01.R;
import com.example.myexercise_01_1c.AlarmService;
import com.example.myexercise_01_1c.Posenet.CameraActivity;
import com.example.myexercise_01_1c.Posenet.PosenetActivity;
import com.example.myexercise_01_1c.model.Alarm;

import java.util.Calendar;

public class AlarmRingingActivity extends AppCompatActivity {
    private static final String TAG = "클래스"+ AlarmRingingActivity.class.getSimpleName();
    Intent serviceIntent;
    TextView timeText;
    boolean flag = true;
    boolean flagEnd = false;
    Intent intent;
    String missionName;
    int missionCount;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(getClass().getSimpleName(), "onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm_ringing);

//        AlarmReceiver.flag = 1;

        // 잠금 화면 위로 activity 띄워줌
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);

        Intent intent = getIntent();
//        Alarm alarm = Alarm.getAlarm(intent);
        Alarm alarm = (Alarm) intent.getSerializableExtra("alarm");


        //알람 라벨 보여줌
        TextView textView_alarmLabel = findViewById(R.id.textView_alarmLabel);
        textView_alarmLabel.setText(alarm.getNAME());

        missionName = alarm.getWORKOUT();
        missionCount = alarm.getCOUNT();

        Uri temp = Uri.parse(alarm.getMUSIC());
        Log.d(TAG, String.valueOf(temp));
        Log.d(TAG, alarm.getMUSIC());
        int volume = alarm.getVOLUME();

        serviceIntent = new Intent(getApplicationContext(), AlarmService.class);
        serviceIntent.putExtra("music", temp);
        serviceIntent.putExtra("volume", volume);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { // Oreo(26) 버전 이후부터는 Background 에서 실행을 금지하기 때문에 Foreground 에서 실행해야 함
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
        showCurrentTime();

    }

    public void onClickButtonFinish(View view) { //해제 버튼 클릭시 호출
        //알람 정보에서 종류, 횟수 가져와서 CameraActivity로 넘겨줌
        if (missionName == null || missionCount == 0) {
            finishActivity();
            Log.d(TAG, "종료");
            return;
        }
        Log.d(TAG, "종료안됨");
        Intent missionIntent = new Intent(this, CameraActivity.class);
        missionIntent.putExtra("missionName", missionName);
        missionIntent.putExtra("missionCount", missionCount);
        if(missionName != null){
            Log.e("링잉미션", missionName);
        }
        startActivityForResult(missionIntent, 100);
//        stopService(serviceIntent); // actFinish 안쓰고 그냥 얘 주석처리하니까 됨
        flagEnd = true; //이게있어야되네..? 없으면 에러남
//        finish(); //액티비티 종료
    }
    private void  finishActivity() {
        finish();
        flagEnd = true;
        stopService(serviceIntent); //알람음 종료
//        AlarmReceiver.flag = 0;
        //        stopForeground(Service.STOP_FOREGROUND_REMOVE); //포그라운드 서비스 종료
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable @org.jetbrains.annotations.Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d(TAG, "onActivityResult");
        //카메라액티비티 종료후 호출됨. 이런방식으로 하던가 아님 세진이 actFinish()만들어서 호출하는 방식도 갠찮을듯.. 나중에 이방식으로 오류생기면 바꿀것
        if(resultCode == RESULT_OK) {
            finishActivity();
            Log.d(TAG, "RESULT_OK임");
        } else {
            Log.d(TAG, "RESULT_OK아님");
        }
    }
    //AlarmRingingActivity 끝내는 함수, 메뉴키 막기 주석처리해야 카메라액티비티 실행가능
    //이 함수 써서 미션 수행하고 나면 오류 뿜으면서 강제종료됨
//    public void actFinish(){
//        Toast.makeText(this, "알람이 해지되었습니다", Toast.LENGTH_SHORT).show();
//        stopService(serviceIntent);
//        flagEnd = true;
//        finish();
//    }
    private void showCurrentTime() {
        timeText =  findViewById(R.id.textView_time);
        new Thread(new Runnable() { //실시간으로 시계출력하기 위한 thread
            @Override
            public void run() {

                while (flag == true) {
                    try {
                        Calendar calendar = Calendar.getInstance();
                        timeText.setText("오전 " + calendar.get(Calendar.HOUR_OF_DAY) + "시 " + calendar.get(Calendar.MINUTE) + "분 " + calendar.get(Calendar.SECOND) + "초");

//                        if (calendar.get(Calendar.HOUR_OF_DAY) > 0 && calendar.get(Calendar.HOUR_OF_DAY) < 12) {
//                            timeText.setText("오전 " + calendar.get(Calendar.HOUR_OF_DAY) + "시 " + calendar.get(Calendar.MINUTE) + "분 " + calendar.get(Calendar.SECOND) + "초");
//                        } else if (calendar.get(Calendar.HOUR_OF_DAY) == 12) {
//                            timeText.setText("오후 " + calendar.get(Calendar.HOUR_OF_DAY) + "시 " + calendar.get(Calendar.MINUTE) + "분 " + calendar.get(Calendar.SECOND) + "초");
//                        } else if (calendar.get(Calendar.HOUR_OF_DAY) > 12 && calendar.get(Calendar.HOUR_OF_DAY) < 24) {
//                            timeText.setText("오후 " + (calendar.get(Calendar.HOUR_OF_DAY) - 12) + "시 " + calendar.get(Calendar.MINUTE) + "분 " + calendar.get(Calendar.SECOND) + "초");
//                        } else if (calendar.get(Calendar.HOUR_OF_DAY) == 0) {
//                            timeText.setText("오전 0시 " + calendar.get(Calendar.MINUTE) + "분 " + calendar.get(Calendar.SECOND) + "초");
//                        }
                        Thread.sleep(1000);
                    } catch (InterruptedException ex) {}
                }
            }
        }).start(); // 실시간으로 시계 출력
    }

    // 뒤로가기 막기
    @Override
    public void onBackPressed() {
//        super.onBackPressed(); // 기존 뒤로 가기 버튼의 기능을 막기 위해 주석 처리 또는 삭제
    }
    long onStopTime = 0;
    // 홈키, 메뉴키 재실행 방식으로 막기
    @Override
    public void onStop() {
        Log.d(TAG,"ONSTOP");
        super.onStop();
        if (!flagEnd && System.currentTimeMillis() > onStopTime + 1500) {         //2초를 더함
            onStopTime = System.currentTimeMillis(); //
            startActivity(new Intent(this, AlarmRingingActivity.class));
            Toast.makeText(this, "재실행", Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    protected void onDestroy() {
        Log.d(TAG,"onDestroy");
        super.onDestroy();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) { //알람 울릴 때 볼륨 버튼 누르면 미디어 음량이 아니라 벨소리 음량 바뀜
        switch(keyCode) {
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                ((AudioManager) getSystemService(Context.AUDIO_SERVICE)).adjustStreamVolume(AudioManager.STREAM_RING, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
                return true;
            case KeyEvent.KEYCODE_VOLUME_UP:
                ((AudioManager) getSystemService(Context.AUDIO_SERVICE)).adjustStreamVolume(AudioManager.STREAM_RING, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }
    /** END OF CODE **/
    //    //메뉴키 막기
//    @Override
//    protected void onPause() {
//        Log.d(CLASS,"onPause");
//        super.onPause();
//        ActivityManager activityManager = (ActivityManager) getApplicationContext().getSystemService(Context.ACTIVITY_SERVICE);
//        activityManager.moveTaskToFront(getTaskId(), 0);
//        Toast.makeText(this, "메뉴키 사용불가.", Toast.LENGTH_SHORT).show();
//    }
    //생명주기테스트..뻘짓! 그래도 지우지말길 나중에 건들일 일 생길듯 액티비티 종료되면안되므로
//    @Override
//    protected void onResume() {
//        Log.d(CLASS,"onResume");
//        super.onResume();
//    }
//    @Override
//    protected void onPause() {
//        Log.d(CLASS,"onPause");
//        Log.d(CLASS,Integer.toString(flag));
//        if (flag==0){
////            super.onRestart();
//            onResume();
//            super.onRestart();
//            super.onResume();}
//        else
//            super.onPause();
//    }
//    @Override
//    protected void onStop() {
//        Log.d(CLASS,"ONSTOP");
//        if (flag==0){
////            super.onRestart();
//            //onResume();
//            onRestart();
//            super.onRestart();
//            super.onResume();}
//        else
//        super.onStop();
//        super.onResume();
//    }
//
//    @Override
//    protected void onRestart() {
//        Log.d(CLASS,"onRestart");
//
//        super.onRestart();
//    }
//
}