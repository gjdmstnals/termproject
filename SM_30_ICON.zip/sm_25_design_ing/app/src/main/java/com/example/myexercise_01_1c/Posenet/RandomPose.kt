/*
 * Copyright 2019 The TensorFlow Authors. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.myexercise_01_1c.Posenet

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import android.util.Log
import org.tensorflow.lite.Interpreter
//import org.tensorflow.lite.gpu.GpuDelegate
import java.io.BufferedReader
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.util.*
import kotlin.collections.ArrayList
import kotlin.math.exp

enum class Device2 {
    CPU,
    NNAPI,
    GPU
}

// Pose 이름과 점수를 담는 class
class Pose {
    var poseName : String = ""
    var score: Float = 0.0f
}

open class RandomPose(
        val context: Context,
        val filename: String = "graph.lite", // 모델파일 이름
        val device: Device2 = Device2.CPU
) : AutoCloseable {
    var lastInferenceTimeNanos: Long = -1
        private set

    /** An Interpreter for the TFLite model.   */
    private var interpreter: Interpreter? = null
    //private var gpuDelegate: GpuDelegate? = null
    private val NUM_LITE_THREADS = 4

    /* Preallocated buffers for storing image data in. */
    private var intValues = IntArray(DIM_IMG_SIZE_X * DIM_IMG_SIZE_Y)


    private fun getInterpreter(): Interpreter {
        if (interpreter != null) {
            return interpreter!!
        }
        val options = Interpreter.Options()
        options.setNumThreads(NUM_LITE_THREADS)
        when (device) {
            Device.CPU -> {
            }
            Device.GPU -> {
                //gpuDelegate = GpuDelegate()
                //options.addDelegate(gpuDelegate)
            }
            Device.NNAPI -> options.setUseNNAPI(true)
        }
        interpreter = Interpreter(loadModelFile(filename, context), options)
        return interpreter!!
    }

    override fun close() {
        interpreter?.close()
        interpreter = null
        //gpuDelegate?.close()
        //gpuDelegate = null
    }

    // 생성자로 생성시 호출됨, 배열들 초기화
    init{
        interpreter = Interpreter(loadModelFile(filename, context))
        labelList = loadLabelList("labels.txt")
        imgData = ByteBuffer.allocateDirect(
                4 * DIM_BATCH_SIZE * DIM_IMG_SIZE_X * DIM_IMG_SIZE_Y * DIM_PIXEL_SIZE)
        imgData!!.order(ByteOrder.nativeOrder())
        labelProbArray = Array(1) { FloatArray(labelList!!.size) }
        filterLabelProbArray = Array(FILTER_STAGES) { FloatArray(labelList!!.size) }
        Log.d(TAG, "Created a Tensorflow Lite Image Classifier.")
    }


    /**
     * Scale the image to a byteBuffer of [-1,1] values.
     */
    // imageclassifier + convertBitmapToByteBuffer
    private fun initInputArray(bitmap: Bitmap) {
        // Convert the image to floating point.
        // imageclassifier에서 convertBitmapToByteBuffer

        if (imgData == null) {
            return
        }
        imgData?.rewind()
        bitmap.getPixels(intValues, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)

        var pixel = 0
        for (i in 0 until DIM_IMG_SIZE_X) {
            for (j in 0 until DIM_IMG_SIZE_Y) {
                val `val` = intValues[pixel++]
                imgData?.putFloat(((`val` shr 16 and 0xFF) - IMAGE_MEAN) / IMAGE_STD)
                imgData?.putFloat(((`val` shr 8 and 0xFF) - IMAGE_MEAN) / IMAGE_STD)
                imgData?.putFloat(((`val` and 0xFF) - IMAGE_MEAN) / IMAGE_STD)
            }
        }
    }

    /** Preload and memory map the model file, returning a MappedByteBuffer containing the model. */
    private fun loadModelFile(path: String, context: Context): MappedByteBuffer {
        val fileDescriptor = context.assets.openFd(path)
        val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
        return inputStream.channel.map(
                FileChannel.MapMode.READ_ONLY, fileDescriptor.startOffset, fileDescriptor.declaredLength
        )
    }

    /**
     * Initializes an outputMap of 1 * x * y * z FloatArrays for the model processing to populate.
     */
    // Posenet.kt 의 initOutputMap
    private fun printTopKLabels(): Pose {
        for (i in labelList!!.indices) {
            sortedLabels.add(
                    AbstractMap.SimpleEntry(labelList!![i], labelProbArray!![0][i]))
//            if (sortedLabels.size > RESULTS_TO_SHOW) {
//                sortedLabels.poll()
//            }
        }

        var pose = Pose()
        val size = sortedLabels.size
        for (i in 0 until size) {
            val label = sortedLabels.poll()
            Log.d("labelScore", label.value.toString())
            pose.poseName = label.key
            pose.score = label.value
        }
        return pose
    }

    private fun loadLabelList(path: String): List<String> {
        val labelList: MutableList<String> = ArrayList()

        val reader = BufferedReader(InputStreamReader(context.assets.open("labels.txt")))

        val iterator = reader.lineSequence().iterator()
        while(iterator.hasNext()) {
            val line = iterator.next()
            labelList.add(line)
        }

        reader.close()
        return labelList
    }

    fun applyFilter() {
        val num_labels = labelList!!.size

        // Low pass filter `labelProbArray` into the first stage of the filter.
        for (j in 0 until num_labels) {
            filterLabelProbArray!![0][j] += FILTER_FACTOR * (labelProbArray!![0][j] -
                    filterLabelProbArray!![0][j])
        }
        // Low pass filter each stage into the next.
        for (i in 1 until FILTER_STAGES) {
            for (j in 0 until num_labels) {
                filterLabelProbArray!![i][j] += FILTER_FACTOR * (filterLabelProbArray!![i - 1][j] -
                        filterLabelProbArray!![i][j])
            }
        }

        // Copy the last stage filter output back to `labelProbArray`.
        for (j in 0 until num_labels) {
            labelProbArray!![0][j] = filterLabelProbArray!![FILTER_STAGES - 1][j]
        }
    }


    /**
     * Estimates the pose for a single person.
     * args:
     *      bitmap: image bitmap of frame that should be processed
     * returns:
     *      person: a Person object containing data about keypoint locations and confidence scores
     */
    @Suppress("UNCHECKED_CAST")
    open fun classifyFrame(bitmap: Bitmap, num: Int): Pose {
        if (interpreter == null) {
            Log.e(TAG, "Image classifier has not been initialized; Skipped.")
        }

        // 랜덤 포즈 배열이 생성되지 않았다면 생성해줌, 랜덤포즈에 사용될 포즈들 randomList에 넣어줌
        if (!randomCreated) {
            randomList[0] = labelList?.get(2)
            randomList[1] = labelList?.get(4)
            randomList[2] = labelList?.get(5)
            var i = 0
//            while (i < 3) {                                 // 중복없는 0~2사이 난수 2개 생성하여 randomNum 배열에 저장
//                val r = Random()
//                randomNum[i] = r.nextInt(3)
//                for (j in 0 until i) {
//                    if (randomNum[i] === randomNum[j]) {
//                        i--
//                    }
//                }
//                i++
//            }
            while (i < 100) {                                 // 중복없는 0~2사이 난수 100개 생성하여 randomNum 배열에 저장
                val r = Random()
                randomNum[i] = r.nextInt(3)
                if (i > 0) {
                    val j = i - 1
                    if (randomNum[i] === randomNum[j]) {
                        i--
                    }
                }
                i++
            }
        }
        Log.e("배열생성" , randomNum.toString())
        // 랜덤 포즈 배열 생성 완료
        // randomList[randomNum[missionCount]] 이렇게 접근하는데 더 짧고 좋은 방법은 생각해보면 나올거같은데 일단 이렇게 둠
        randomCreated = true

        initInputArray(bitmap)

        val startTime = SystemClock.uptimeMillis()
        interpreter?.run(imgData, labelProbArray)
        val endTime = SystemClock.uptimeMillis()
        Log.d(TAG, "Timecost to run model inference: " + (endTime - startTime).toString())

        // smooth the results
        applyFilter()

        // print the results
        return printTopKLabels()
    }


    companion object{
        private const val TAG = "RandomPose.kt"

        /** Number of results to show in the UI.  */
        private val RESULTS_TO_SHOW = 1

        /** Dimensions of inputs.  */
        private val DIM_BATCH_SIZE = 1

        private val DIM_PIXEL_SIZE = 3

        const val DIM_IMG_SIZE_X = 224
        const val DIM_IMG_SIZE_Y = 224

        private val IMAGE_MEAN = 128
        private val IMAGE_STD = 128.0f

        var labelList: List<String>? = null
        var randomList = arrayOfNulls<String>(3)
        var randomNum = arrayOfNulls<Int>(100)
        var missionCount = 0
        var randomCreated = false
        var completeMission = false

        /** A ByteBuffer to hold image data, to be feed into Tensorflow Lite as inputs.  */
        private var imgData: ByteBuffer? = null

        /** An array to hold inference results, to be feed into Tensorflow Lite as outputs.  */
        private var labelProbArray: Array<FloatArray>? = null

        /** multi-stage low pass filter  */
        private var filterLabelProbArray: Array<FloatArray>? = null
        private val FILTER_STAGES = 3
        private val FILTER_FACTOR = 0.4f

        private var sortedLabels = PriorityQueue<Map.Entry<String, Float>>(
                RESULTS_TO_SHOW,
                object : Comparator<Map.Entry<String?, Float?>?> {
                    override fun compare(o1: Map.Entry<String?, Float?>?, o2: Map.Entry<String?, Float?>?): Int {
                        return o1!!.value!!.compareTo(o2!!.value!!)
                    }
                })
    }
}
