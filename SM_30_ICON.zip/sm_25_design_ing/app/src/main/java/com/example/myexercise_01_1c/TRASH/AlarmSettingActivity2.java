//토글 버튼 없애기 전
//package com.example.myexercise_01_1c;
//
//import android.app.AlarmManager;
//import android.app.AlertDialog;
//import android.app.PendingIntent;
//import android.content.Context;
//import android.content.Intent;
//import android.media.AudioManager;
//import android.media.MediaPlayer;
//import android.media.Ringtone;
//import android.media.RingtoneManager;
//import android.net.Uri;
//import android.os.Bundle;
//import android.util.Log;
//import android.view.Menu;
//import android.view.MenuInflater;
//import android.view.MenuItem;
//import android.view.View;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.LinearLayout;
//import android.widget.NumberPicker;
//import android.widget.RadioButton;
//import android.widget.RadioGroup;
//import android.widget.SeekBar;
//import android.widget.TextView;
//import android.widget.TimePicker;
//import android.widget.Toast;
//import android.widget.ToggleButton;
//
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.ActionBar;
//import androidx.appcompat.app.AppCompatActivity;
//
//import com.example.myexercise_01.R;
//import com.example.myexercise_01_1c.db.DBHelper;
//import com.example.myexercise_01_1c.model.Alarm;
//import com.google.android.material.chip.Chip;
//import com.google.android.material.chip.ChipGroup;
//
//import java.text.SimpleDateFormat;
//import java.util.BitSet;
//import java.util.Calendar;
//import java.util.Locale;
//
//public class AlarmSettingActivity2 extends AppCompatActivity implements View.OnClickListener {
//    private AlarmManager alarmManager;
//    private TimePicker timePicker;
//    private ChipGroup chipGroup;
//    private PendingIntent pendingIntent;
//    private EditText alarmName;
//    private DBHelper dbHelper = DBHelper.getInstance(this);
//    ToggleButton button_playAlarm;
//    AlertDialog aDialog;
//    private Button button_alarm_save;
//
//    private TextView textView_ringToneTitle;
//    private final static int REQUESTCODE_RINGTONE_PICKER = 1000;
//    private String m_strRingToneUri;
//    private RingtoneManager ringtoneManager;
//    private Ringtone curRingtone;
//    private RadioGroup radioGroup_mission_list;          //미션버튼들을 가진 Group
//    private RadioButton button_mission_selected;        //선택된 미션버튼
//    private String Exer;
//    private LinearLayout layout_mission_choose, layout_ringtoneChoose;    //미션설정 다이얼로그를 불러올 LinearLayout
//    private TextView textView_missionName, testView_missionCount, button_mission_save, button_mission_cancel;
//    private NumberPicker numberPicker_mission_count;
//    Intent intent;
//
//    private SeekBar seekBar_volume;
//    private int volume_value = 0;
//    long id;
//    int setting; //알람 id값
//    Uri ringUri;
//    int volume;
//    float volume_float;
//    MediaPlayer mediaPlayer = new MediaPlayer();
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_alarm_setting);
//
//        init();         // 액티비티 세팅
//        missionInit();  // 미션 다이얼로그창 세팅
//
//        initializeAlarmSetting(); //알람값 세팅
//        actionBarSetting();       //상단툴바 세팅
//
//    }
//
//    private void missionInit() {
//        AlertDialog.Builder builder = new AlertDialog.Builder(this);
//        final View view = this.getLayoutInflater().inflate(R.layout.customdialog, null);
//        builder.setView(view);
//        aDialog = builder.create();
//
//        /* 뷰바인딩 */
//        numberPicker_mission_count = (NumberPicker) view.findViewById(R.id.numberPicker);
//        radioGroup_mission_list = (RadioGroup)view.findViewById(R.id.missionList);
//        //check 된 버튼인지 확인해서 체크된 버튼으로 초기화, 아무것도 선택하지 않으면 RandomPose 로 설정
//        button_mission_selected = (RadioButton)view.findViewById(radioGroup_mission_list.getCheckedRadioButtonId());
//        button_mission_save = (TextView)view.findViewById(R.id.custom_dialog_positive); //저장 버튼
//        button_mission_cancel = (TextView)view.findViewById(R.id.custom_dialog_negative); //취소 버튼
//
//        textView_missionName = (TextView)findViewById(R.id.missionTitle); //미션 이름
//        testView_missionCount = (TextView)findViewById(R.id.missionCount); //미션 횟수
//
//        /* 넘버피커 세팅 */
//        numberPicker_mission_count.setMinValue(0);    //횟수 최솟값
//        numberPicker_mission_count.setMaxValue(100);  //횟수 최댓값
//        numberPicker_mission_count.setValue(0); //디폴트값 0 넣음
//
//        //radioGroup_mission_list.clearCheck(); //미션 설정 누를때마다, 체크박스가 비워진 상태로 보이기 위함.
//        /* 리스너 달기 */
//        radioGroup_mission_list.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(RadioGroup group, int checkedId) {
//                if(checkedId == R.id.mSquat){
//                    button_mission_selected = (RadioButton)view.findViewById(R.id.mSquat);
//                    Exer = "Squat";
//                }else{
//                    button_mission_selected = (RadioButton)view.findViewById(R.id.mRandom);
//                    Exer = "Random";
//                }
//            }
//        });
//        //NumberPicker(횟수) 값 바뀔때마다 최신화?
////        numberPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
////            @Override
////            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
////                picker.setValue(newVal);
////            }
////        });
//        button_mission_save.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v){ //저장버튼 누를 시, 선택한 미션과 횟수를 각각의 textview에 쓰고 다이얼로그 종료
//                String sB = button_mission_selected.getText().toString();
//                textView_missionName.setText(sB);
//                testView_missionCount.setText(String.valueOf(numberPicker_mission_count.getValue()));
//                Toast.makeText(AlarmSettingActivity2.this, button_mission_selected.getText().toString(), Toast.LENGTH_SHORT);
//                aDialog.dismiss();
//            }
//        });
//        button_mission_cancel.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v){ //취소버튼 누를 시, 미션과 횟수의 textview에 nothing choosen, - 를 쓰고 다이얼로그 종료
//                textView_missionName.setText("Nothing Choosen");
//                testView_missionCount.setText("-");
//                aDialog.dismiss();
//            }
//        });
//    }
//
//    private void init() {
//        //뷰바인딩
//        button_playAlarm = findViewById(R.id.button_playAlarm);
//        timePicker = findViewById(R.id.timePicker);
//        chipGroup = findViewById(R.id.chipGroup);
//        alarmName = findViewById((R.id.editText_label));
//        textView_ringToneTitle = findViewById(R.id.textView_ringToneTitle);
//        ringtoneManager = new RingtoneManager(this);
//        seekBar_volume = (SeekBar)findViewById(R.id.seekBar_volume); //알람 볼륨 슬라이드바
//        layout_ringtoneChoose = findViewById(R.id.layout_ringtoneChoose); //알람 볼륨 슬라이드바
//        layout_mission_choose = (LinearLayout)findViewById(R.id.layout_mission_choose); //미션 설정
//        button_alarm_save = findViewById(R.id.button_alarm_save); //미션 설정
//
//        //클릭리스너
//        layout_ringtoneChoose.setOnClickListener(this);
//        layout_mission_choose.setOnClickListener(this);
//        button_alarm_save.setOnClickListener(this);
//        button_playAlarm.setOnClickListener(this);
//
//
//        AudioManager audioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
//        int maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
//        int curVol   = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
//
//        seekBar_volume.setMax(maxVol);
//        seekBar_volume.setProgress(curVol);
//
//        //알람 볼륨 조절
//        seekBar_volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
//            @Override
//            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
//                volume = progress;
//                volume_float = (float) (1 - (Math.log(maxVol - seekBar_volume.getProgress()) / Math.log(maxVol)));
//                Log.d("onProgressChanged", String.valueOf(volume));
//                Log.d("onProgressChanged", String.valueOf(volume_float));
//                // 알람 볼륨 설정
////                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress,AudioManager.FLAG_PLAY_SOUND);
//
//                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, volume,0);
////                seekBar.setProgress(progress); //이걸 넣어야되나?
//
//            }
//            @Override
//            public void onStartTrackingTouch(SeekBar seekBar) {
//                volume_value = seekBar_volume.getProgress();
//            }
//            @Override
//            public void onStopTrackingTouch(SeekBar seekBar) {
//                volume_value = seekBar_volume.getProgress();
//            }
//        });
//
//    }
//    //앱 상단 툴바(액션바) 설정
//    private void actionBarSetting() {
//        ActionBar actionBar = getSupportActionBar();
//        if (setting == 0) actionBar.setTitle("새 알람 추가");
//        if (setting == 1) actionBar.setTitle("알람 수정");
//        actionBar.setDisplayHomeAsUpEnabled(true); // 뒤로가기 버튼 추가
//    }
//    // 툴바 메뉴 설정하는 메서드
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        if (setting == 0)   return super.onCreateOptionsMenu(menu);
//        MenuInflater inflater = getMenuInflater();
//        inflater.inflate(R.menu.menu_settingactivity, menu); // menu_settingactivity 메뉴(휴지통아이콘)를 toolbar 메뉴 버튼으로 설정
//        return true;
//    }
//    //툴바 메뉴의 아이템 선택했을때 호출되는 메서드
//    @Override
//    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//        switch (item.getItemId()) {
//            case R.id.menu_delete :
//                dbHelper.deleteIdAlarm(id);     //id에 해당하는 알람 삭제
//                finish();   //현재 액티비티 종료 (메인액티비티로 돌아감)
//            case android.R.id.home:{ //toolbar의 back키 눌렀을 때 동작
//                finish();
//                return true;
//            }
//        }
//        return super.onOptionsItemSelected(item);
//    }
//    public void stopMusic() { //음악 재생 중지
//        Log.d(getClass().getSimpleName(), "stopMusic");
//        if (mediaPlayer != null) {
//            mediaPlayer.stop();     // 5. 재생 중지
//            mediaPlayer.reset();
//            mediaPlayer.release();    // 6. MediaPlayer 리소스 해제
//            mediaPlayer = null;
//        }
//    }
//    public void playMusic() {
//        case R.id.button_playAlarm:
//        if (button_playAlarm.isChecked()) {
//            stopMusic();
//            if(ringUri == null) {
//                ringUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
//                Log.d("zzzringUri널임",String.valueOf(ringUri));
//            } else {
//                Log.d("zzz", String.valueOf(ringUri));
//            }
//            mediaPlayer = MediaPlayer.create(getApplicationContext(), ringUri);
//            mediaPlayer.setVolume(volume_float, volume_float);
//            mediaPlayer.start();
//        } else {
//            stopMusic();
//        }
//
//    }
//
//    @Override
//    public void onClick(View v) {
//        switch (v.getId()) {
//            case R.id.button_playAlarm:
//                if (button_playAlarm.isChecked()) {
//                    stopMusic();
//                    if(ringUri == null) {
//                    ringUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
//                    Log.d("zzzringUri널임",String.valueOf(ringUri));
//                } else {
//                    Log.d("zzz", String.valueOf(ringUri));
//                }
//                    mediaPlayer = MediaPlayer.create(getApplicationContext(), ringUri);
//                    mediaPlayer.setVolume(volume_float, volume_float);
//                    mediaPlayer.start();
//                } else {
//                    stopMusic();
//                }
////                TextView volumeText = (TextView)findViewById(R.id.volume);
////                volumeText.setText(String.valueOf(progress));
////                startRingtone(ringUri);
//
//
////// 알람 소리 재생
////                if(ringUri == null) {
////                    ringUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
////                    Log.d("zzzringUri널임",String.valueOf(ringUri));
////                } else {
////                    Log.d("zzz", String.valueOf(ringUri));
////                }
////                mediaPlayer = MediaPlayer.create(getApplicationContext(), ringUri);
//////                try {
//////                    mp.setDataSource(ringUri.toString());
//////                } catch (IOException e) {
//////                    e.printStackTrace();
//////                }
//////                mp.setLooping(true);
////                mediaPlayer.setVolume(volume_float, volume_float);
//////                try {
//////                    mp.prepare();
//////                } catch (IOException e) {
//////                    e.printStackTrace();
//////                }
////                mediaPlayer.start();
//                break;
//
//            case R.id.button_alarm_save: //알람 저장 버튼
//                //dbHelper.deleteIdAlarm(id);     //id에 해당하는 알람 삭제
//                saveAlarm(id);                    //새 알람값 저장
//                finish(); //액티비티 종료
//                break;
//            case R.id.layout_ringtoneChoose: //벨소리 설정 레이아웃 영역
//                startRingtoneChooseActivity();
//                break;
//            case R.id.layout_mission_choose: //미션 설정 레이아웃 영역
//                aDialog.show(); //미션설정다이얼로그창 띄우기
//                break;
//        }
//    }
//
//
//    private void initializeAlarmSetting() {
//        intent = getIntent();
//        setting = intent.getIntExtra("setting", 0); //값이 0이면 새알람추가, 1이면 기존 알람 수정
//
//        if (setting == 0) { //+버튼을 눌러서 들어온 것, 현재시각으로 timepicker 설정
//            final Calendar c = Calendar.getInstance();
//            final int minutes = c.get(Calendar.MINUTE);    //분
//            final int hours = c.get(Calendar.HOUR_OF_DAY); //현재시간t
//
//            timePicker.setHour(hours);
//            timePicker.setMinute(minutes);
//        }
//        if (setting == 1) {      //기존 알람을 눌러서 들어온 것, 기존알람 시각으로 설정
//            //아래값들을 db에서 읽어오는 형태로 바꿔야함..
//            id =  intent.getLongExtra("id", 0);
//            long time =  intent.getLongExtra("time", 0);
//
//            SimpleDateFormat HOUR_FORMAT = new SimpleDateFormat("H", Locale.getDefault());
//            SimpleDateFormat MINITUE_FORMAT = new SimpleDateFormat("m", Locale.getDefault());
//            int hour = Integer.parseInt(HOUR_FORMAT.format(time));
//            int min = Integer.parseInt(MINITUE_FORMAT.format(time));
//
//            timePicker.setHour(hour);
//            timePicker.setMinute(min);
//        }
//    }
//
//    /* 알람 DB에 저장*/
//    private void saveAlarm(long alarmID) {
//        // 시간 설정
//        Alarm alarm;
//        Calendar time = Calendar.getInstance();
//        time.set(Calendar.HOUR_OF_DAY, timePicker.getHour());
//        time.set(Calendar.MINUTE, timePicker.getMinute());
//        time.set(Calendar.SECOND, 0);
//
//        if (time.before(Calendar.getInstance())) { // 현재시간보다 이전이면
//            time.add(Calendar.DATE, 1);    // 다음날로 설정
//        }
//
//        if(ringUri == null) {
//            ringUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
//        }
//        if (setting == 0) {
//            alarm = new Alarm(time.getTimeInMillis(), getDayBitSet(), alarmName.getText().toString(),
//                    Exer, numberPicker_mission_count.getValue(), ringUri, volume_value, true);
//            Log.d("ㅋㅋㅋ저장된형태", String.valueOf(time.getTimeInMillis()));
//
//            long id = dbHelper.addAlarm(alarm);//db에 alarm값 저장
//            alarm.setID(id);                   //alarm의 id변수에 db의 id값 저장
//            AlarmReceiver.registerAlarm(getApplicationContext(), alarm); //알람매니저에 알람 서비스 등록
//        }
//        else {
//            alarm = new Alarm(time.getTimeInMillis(), getDayBitSet(), alarmName.getText().toString(),
//                    Exer, numberPicker_mission_count.getValue(), ringUri, volume_value);
//            dbHelper.updateAlarm(alarmID, alarm);
//            AlarmReceiver.registerAlarm(getApplicationContext(), alarm); //DB 정보 바꾸고 바로 알람 등록
//        }
//
//        Log.d("haha-아이디", String.valueOf(id));
//        Log.d("haha-리퀘스트", String.valueOf(alarm.getRequestCode()));
//
//    }
//
//    /* 요일 bitset 저장 후 bitset반환 */
//    private BitSet getDayBitSet() {
//        BitSet bitset = new BitSet(7);
//        for (int i = 0; i < chipGroup.getChildCount(); i++) {
//            Chip chip = (Chip) chipGroup.getChildAt(i);
//            if (chip.isChecked()) bitset.set(i);
//        }
//        //디버깅용
//        StringBuilder sb2= new StringBuilder(""); for (int i = 0; i < 7; i++) sb2.append(bitset.get(i)).append(", ");  Log.d("saveDay", sb2.toString());
//        //디버깅용
//        return bitset;
//    }
//
//    @Override //벨소리 설정 후 다시 알람세팅액티비티로 돌아왔을 때 호출되는 함수
//    protected void onActivityResult(int requestCode, int resultCode, Intent data){
//        super.onActivityResult(requestCode, resultCode, data);
//        if(requestCode == REQUESTCODE_RINGTONE_PICKER){
//            if(resultCode == RESULT_OK){
//                ringUri = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
//                Ringtone ringtone = RingtoneManager.getRingtone(this, ringUri);
//                if(ringUri != null){
//                    m_strRingToneUri = ringUri.toString();
//                    textView_ringToneTitle.setText(ringtone.getTitle(this));
//                    startRingtone(ringUri);
//                }else{
//                    m_strRingToneUri = null;
//                    textView_ringToneTitle.setText("기본음");
//                }
//            }
//        }
//    }
//
//    public void startRingtoneChooseActivity() {
//        Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER); // 암시적 Intent
//
//        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Ringtone List"); // 제목을 넣는다
//        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false); // 무음을 선택 리스트에서 제외
//        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true); // 기본 벨소리는 선택 리스트에 넣는다.
//
//        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL);
//
//        if(m_strRingToneUri != null && m_strRingToneUri.isEmpty()){
//            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(m_strRingToneUri));
//        }
//        this.startActivityForResult(intent, REQUESTCODE_RINGTONE_PICKER);
//    }
//
//
//
//    /** END OF CODE **/
//    /*필요없거나 아직 안쓰는것들. 접어놓으셈!!*/
//    private void startRingtone(Uri RingtoneUri){
//        this.releaseRingtone();
//        try{
//            curRingtone = ringtoneManager.getRingtone(this, RingtoneUri);
//
//            if(curRingtone == null){
//                throw new Exception("Nothing Choosen");
//            }
//            curRingtone.play();
//        }catch (Exception e){
//            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
//            Log.e("AlarmSettingActivity", e.getMessage());
//            e.printStackTrace();
//        }
//    }
//    private void releaseRingtone(){
//        if(curRingtone != null){
//            if(curRingtone.isPlaying()){
//                curRingtone.stop();
//                curRingtone = null;
//            }
//        }
//    }
////    /* 알람 중지 */
////    private void stop() {
////        if (this.pendingIntent == null) {
////            return;
////        }
////        // 알람 취소
////        this.alarmManager.cancel(this.pendingIntent);
////        // 알람 중지 Broadcast
////        Intent intent = new Intent(this, AlarmReceiver.class);
////        intent.putExtra("state","off");
////        sendBroadcast(intent);
////        this.pendingIntent = null;
////    }
//}