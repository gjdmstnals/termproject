package com.example.myexercise_01_1c;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.myexercise_01.R;
import com.example.myexercise_01_1c.db.DBHelper;
import com.example.myexercise_01_1c.model.Alarm;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.text.SimpleDateFormat;
import java.util.BitSet;
import java.util.Calendar;
import java.util.Locale;

public class AlarmSettingActivity extends AppCompatActivity implements View.OnClickListener {
    private AlarmManager alarmManager;
    private TimePicker timePicker;
    private ChipGroup chipGroup;
    private PendingIntent pendingIntent;
    private EditText editText_alarmName;
    private DBHelper dbHelper = DBHelper.getInstance(this);
    AlertDialog aDialog;
    private Button button_alarm_save;

    private TextView textView_ringToneTitle;
    private final static int REQUESTCODE_RINGTONE_PICKER = 1000;
    private String ringtoneUriStr;
    private RingtoneManager ringtoneManager;
    private Ringtone curRingtone;
    private RadioGroup radioGroup_mission_list;          //미션버튼들을 가진 Group
    private RadioButton button_mission_selected;        //선택된 미션버튼
    private String Exer;
    private CardView layout_mission_choose;    //미션설정 다이얼로그를 불러올 LinearLayout
    private CardView layout_ringtoneChoose;    //미션설정 다이얼로그를 불러올 LinearLayout
    private TextView textView_missionName, testView_missionCount, button_mission_save, button_mission_cancel;
    private NumberPicker numberPicker_mission_count;
    Intent intent;
    AudioManager audioManager;
    View view; //미션다이얼로그 뷰

    private SeekBar seekBar_volume;
    private int volume_value = 0;
    long id;
    int setting; //알람 id값
    Uri ringtoneUri;
    int volume;
    float volume_float;
    MediaPlayer mediaPlayer = new MediaPlayer();
    //    볼륨 관련
    int maxVol;
    private String TAG = "클래스"+getClass().getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm_setting);

        init();         // 액티비티 세팅
        missionInit();  // 미션 다이얼로그창 세팅

        initializeAlarmSetting(); //알람값 세팅
        setToolbar();       //상단툴바 세팅

    }

    private void missionInit() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        view = this.getLayoutInflater().inflate(R.layout.customdialog, null);
        builder.setView(view);
        aDialog = builder.create();

        /* 뷰바인딩 */
        numberPicker_mission_count = (NumberPicker) view.findViewById(R.id.numberPicker);
        radioGroup_mission_list = (RadioGroup)view.findViewById(R.id.missionList);

        button_mission_save = (TextView)view.findViewById(R.id.custom_dialog_positive); //저장 버튼
        button_mission_cancel = (TextView)view.findViewById(R.id.custom_dialog_negative); //취소 버튼

        textView_missionName = (TextView)findViewById(R.id.missionTitle); //미션 이름
        testView_missionCount = (TextView)findViewById(R.id.missionCount); //미션 횟수

        /* 넘버피커 세팅 */
        numberPicker_mission_count.setMinValue(1);    //횟수 최솟값
        numberPicker_mission_count.setMaxValue(100);  //횟수 최댓값

        //기본적으로 선택된 놈 스쿼트
//        button_mission_selected = (RadioButton)view.findViewById(R.id.mSquat);


        /* 리스너 달기 */
        radioGroup_mission_list.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.mSquat){
                    button_mission_selected = (RadioButton)view.findViewById(R.id.mSquat);
//                    Exer = "Squat";
                }else{
                    button_mission_selected = (RadioButton)view.findViewById(R.id.mRandom);
//                    Exer = "Random";
                }
//                Exer = (String) button_mission_selected.getText(); //위코드랑 동일해서 이걸로 대체했음, 대체하면 수정할때 에러남 ㅎ
            }
        });

        button_mission_save.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){ //저장버튼 누를 시, 선택한 미션과 횟수를 각각의 textview에 쓰고 다이얼로그 종료
//                if (button_mission_selected == null) {
//                    textView_missionName.setText("설정된 미션 없음");
//                    testView_missionCount.setText("");
//                } else {
                if (button_mission_selected == null) {
                    Log.d(TAG, "널");
                    button_mission_selected = (RadioButton) view.findViewById(R.id.mSquat);
                }
                else
                    Log.d(TAG, "널아님");
                String missionStr = button_mission_selected.getText().toString();
                textView_missionName.setText(missionStr);
                String countStr = numberPicker_mission_count.getValue() + "회";
                testView_missionCount.setText(countStr);
//                }
                Toast.makeText(AlarmSettingActivity.this, button_mission_selected.getText().toString(), Toast.LENGTH_SHORT);
                Exer = (String) button_mission_selected.getText();
                aDialog.dismiss();
            }
        });
        button_mission_cancel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){ //취소버튼 누를 시, 미션과 횟수의 textview에 nothing choosen, - 를 쓰고 다이얼로그 종료
//                Exer = null;
                button_mission_selected = null;
                textView_missionName.setText("설정된 미션 없음");
                testView_missionCount.setText("");
                aDialog.dismiss();
            }
        });
    }

    private void init() {
        //뷰바인딩
        timePicker = findViewById(R.id.timePicker);
        chipGroup = findViewById(R.id.chipGroup);
        editText_alarmName = findViewById((R.id.editText_label));
        textView_ringToneTitle = findViewById(R.id.textView_ringToneTitle);
        ringtoneManager = new RingtoneManager(this);
        seekBar_volume = (SeekBar)findViewById(R.id.seekBar_volume); //알람 볼륨 슬라이드바
        layout_ringtoneChoose = findViewById(R.id.layout_ringtoneChoose); //알람 볼륨 슬라이드바
        layout_mission_choose = findViewById(R.id.layout_mission_choose); //미션 설정
        button_alarm_save = findViewById(R.id.button_alarm_save); //미션 설정

        //클릭리스너
        layout_ringtoneChoose.setOnClickListener(this);
        layout_mission_choose.setOnClickListener(this);
        button_alarm_save.setOnClickListener(this);

        audioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
        maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int curVol   = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);

        seekBar_volume.setMax(maxVol);

        //알람 볼륨 조절
        seekBar_volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int flagStart = 0;
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                volume = progress;
                volume_float = (float) (1 - (Math.log(maxVol - seekBar_volume.getProgress()) / Math.log(maxVol)));
                Log.d("onProgressChanged", String.valueOf(volume));
                Log.d("onProgressChanged", String.valueOf(volume_float));
                // 알람 볼륨 설정
//                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress,AudioManager.FLAG_PLAY_SOUND);
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, volume,0);
//                seekBar.setProgress(progress); //이걸 넣어야되나? 안넣어도 됨

                if (flagStart == 1)  //한번이라도 터치된 적 있으면, progress bar가 움직일떄마다 재생
                    playMusic();
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
//                volume_value = seekBar_volume.getProgress();
                flagStart = 1;
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
//                volume_value = seekBar_volume.getProgress();
            }
        });

    }
    //앱 상단 툴바(액션바) 설정
    private void setToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView textView_title = toolbar.findViewById(R.id.textView_title);
        setSupportActionBar(toolbar); // 내 툴바를 액티비티의 앱바로 설정
        getSupportActionBar().setDisplayShowTitleEnabled(false); //기본 타이틀 보여줄지 말지 설정
//        getSupportActionBar().setTitle("새 알람 추가");
        if (setting == 0) textView_title.setText("새 알람 추가");
        if (setting == 1) textView_title.setText("알람 편집");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true); // 뒤로가기 버튼 추가
    }
    // 툴바 메뉴 설정하는 메서드
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (setting == 0)   return super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_settingactivity, menu); // menu_settingactivity 메뉴(휴지통아이콘)를 toolbar 메뉴 버튼으로 설정
        return true;
    }
    //툴바 메뉴의 아이템 선택했을때 호출되는 메서드
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_delete :
                dbHelper.deleteIdAlarm(id);     //id에 해당하는 알람 삭제
                finish();   //현재 액티비티 종료 (메인액티비티로 돌아감)
            case android.R.id.home:{ //toolbar의 back키 눌렀을 때 동작
                finish();
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }
    public void stopMusic() { //음악 재생 중지
        Log.d(getClass().getSimpleName(), "stopMusic");
        if (mediaPlayer != null) {
            mediaPlayer.stop();     // 5. 재생 중지
            mediaPlayer.reset();
            mediaPlayer.release();    // 6. MediaPlayer 리소스 해제
            mediaPlayer = null;
        }
    }
    public void playMusic() {
        stopMusic();
        if(ringtoneUri == null) {
            ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            Log.d("zzzringUri널임",String.valueOf(ringtoneUri));
        } else {
            Log.d("zzz", String.valueOf(ringtoneUri));
        }
        mediaPlayer = MediaPlayer.create(getApplicationContext(), ringtoneUri);
        mediaPlayer.setVolume(volume_float, volume_float);
        mediaPlayer.start();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button_alarm_save: //알람 저장 버튼
                //dbHelper.deleteIdAlarm(id);     //id에 해당하는 알람 삭제
                saveAlarm(id);                    //새 알람값 저장
                finish(); //액티비티 종료
                break;
            case R.id.layout_ringtoneChoose: //벨소리 설정 레이아웃 영역
                startRingtoneChooseActivity();
                break;
            case R.id.layout_mission_choose: //미션 설정 레이아웃 영역
                aDialog.show(); //미션설정다이얼로그창 띄우기
                break;
        }
    }

    private void initializeAlarmSetting() {
        intent = getIntent();
        setting = intent.getIntExtra("setting", 0); //값이 0이면 새알람추가, 1이면 기존 알람 수정

        if (setting == 0) { //+버튼을 눌러서 들어온 것, 현재시각으로 timepicker 설정
            //타임 피커 세팅
            final Calendar c = Calendar.getInstance();
            final int minutes = c.get(Calendar.MINUTE);    //분
            final int hours = c.get(Calendar.HOUR_OF_DAY); //현재시간t

            timePicker.setHour(hours);
            timePicker.setMinute(minutes);

            //
            ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            ringtoneUriStr = ringtoneUri.toString();
            int curVol   = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            seekBar_volume.setProgress(curVol);
            numberPicker_mission_count.setValue(1); //디폴트값 1 넣음
        }
        if (setting == 1) {      //기존 알람을 눌러서 들어온 것, 기존알람 시각으로 설정
            //time picker 세팅
            id =  intent.getLongExtra("id", 0);

            Alarm originalAlarm = dbHelper.getAlarm(id);

            //시간 복원
            long time = originalAlarm.getTIME();
            SimpleDateFormat HOUR_FORMAT = new SimpleDateFormat("H", Locale.getDefault());
            SimpleDateFormat MINITUE_FORMAT = new SimpleDateFormat("m", Locale.getDefault());
            int hour = Integer.parseInt(HOUR_FORMAT.format(time));
            int min = Integer.parseInt(MINITUE_FORMAT.format(time));
            timePicker.setHour(hour);
            timePicker.setMinute(min);

            //운동미션 복원
            if (originalAlarm.getWORKOUT() == null || originalAlarm.getCOUNT() == 0) { //설정된 미션 없거나 횟수가 0인 경우
                Log.d("zzzz3", String.valueOf(originalAlarm.getWORKOUT()));
                textView_missionName.setText("설정된 미션 없음");
                testView_missionCount.setText("");
            } else {
                String countStr = originalAlarm.getCOUNT() + "회";
                testView_missionCount.setText(countStr);
                textView_missionName.setText(String.valueOf(originalAlarm.getWORKOUT()));

//                기존에 선택됐던 값으로 레디오버튼 설정

                if (originalAlarm.getWORKOUT().equals("Squat")) {
                    button_mission_selected = (RadioButton)view.findViewById(R.id.mSquat);
                    Log.d(TAG, "스쿼트임");
                } else if (originalAlarm.getWORKOUT().equals("Random Pose")){
                    button_mission_selected = (RadioButton)view.findViewById(R.id.mRandom);
                    Log.d(TAG, "다른거임");
                }
                button_mission_selected.setChecked(true); //이거 안하면 실제론 스쿼트에 체크가 돼있더라도, 체크버튼 표시가 안돼있더라


            }
            numberPicker_mission_count.setValue(originalAlarm.getCOUNT());

            //라벨 복원
            if (originalAlarm.getNAME() == null) editText_alarmName.setText("알람 이름 설정");
            else                                 editText_alarmName.setText(originalAlarm.getNAME());

            /*벨소리 복원*/
            //볼륨복원
            seekBar_volume.setProgress(originalAlarm.getVOLUME());
            //벨소리 이름 복원
            ringtoneUri = Uri.parse(originalAlarm.getMUSIC());
            ringtoneUriStr = ringtoneUri.toString(); //content://..어쩌구 경로 저장돼있음
            Ringtone ringtone = RingtoneManager.getRingtone(this, ringtoneUri);
            textView_ringToneTitle.setText(ringtone.getTitle(this));    //링톤 타이틀 설정

            /*요일 복원*/
            ((Chip) chipGroup.getChildAt(0)).setChecked(originalAlarm.getMON());
            ((Chip) chipGroup.getChildAt(1)).setChecked(originalAlarm.getTUE());
            ((Chip) chipGroup.getChildAt(2)).setChecked(originalAlarm.getWED());
            ((Chip) chipGroup.getChildAt(3)).setChecked(originalAlarm.getTHU());
            ((Chip) chipGroup.getChildAt(4)).setChecked(originalAlarm.getFRI());
            ((Chip) chipGroup.getChildAt(5)).setChecked(originalAlarm.getSAT());
            ((Chip) chipGroup.getChildAt(6)).setChecked(originalAlarm.getSUN());
        }
    }

    /* 알람 DB에 저장, 알람 등록*/
    private void saveAlarm(long alarmID) {
        // 시간 설정
        Alarm alarm;
        Calendar time = Calendar.getInstance();
        time.set(Calendar.HOUR_OF_DAY, timePicker.getHour());
        time.set(Calendar.MINUTE, timePicker.getMinute());
        time.set(Calendar.SECOND, 0);

        if (time.before(Calendar.getInstance())) { // 현재시간보다 이전이면
            time.add(Calendar.DATE, 1);    // 다음날로 설정
        }
        if (button_mission_selected != null)
            Exer = (String) button_mission_selected.getText();

        if (setting == 0) {
            alarm = new Alarm(time.getTimeInMillis(), getDayBitSet(), editText_alarmName.getText().toString(),
                    Exer, numberPicker_mission_count.getValue(), ringtoneUriStr, volume, true);
            Log.d("ㅋㅋㅋ저장된형태", String.valueOf(time.getTimeInMillis()));

            long id = dbHelper.addAlarm(alarm);//db에 alarm값 저장
            alarm.setID(id);                   //alarm의 id변수에 db의 id값 저장
            AlarmReceiver.registerAlarm(getApplicationContext(), alarm); //알람매니저에 알람 서비스 등록
        }
        else {
            //기존 alarm id값을 이용한 alarm 객체 생성
            alarm = new Alarm(id, time.getTimeInMillis(), getDayBitSet(), editText_alarmName.getText().toString(),
                    Exer, numberPicker_mission_count.getValue(), ringtoneUriStr, volume, true);
            dbHelper.updateAlarm(alarmID, alarm);
            AlarmReceiver.registerAlarm(getApplicationContext(), alarm); //DB 정보 바꾸고 바로 알람 등록
        }

        Log.d("haha-아이디", String.valueOf(id));
        Log.d("haha-리퀘스트", String.valueOf(alarm.getRequestCode()));

    }

    /* 요일 bitset 저장 후 bitset반환 */
    private BitSet getDayBitSet() {
        BitSet bitset = new BitSet(7);
        for (int i = 0; i < chipGroup.getChildCount(); i++) {
            Chip chip = (Chip) chipGroup.getChildAt(i);
            if (chip.isChecked()) bitset.set(i);
        }
        //디버깅용
        StringBuilder sb2= new StringBuilder(""); for (int i = 0; i < 7; i++) sb2.append(bitset.get(i)).append(", ");  Log.d("saveDay", sb2.toString());
        //디버깅용
        return bitset;
    }

    @Override //벨소리 설정 후 다시 알람세팅액티비티로 돌아왔을 때 호출되는 함수
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQUESTCODE_RINGTONE_PICKER){
            if(resultCode == RESULT_OK){
                ringtoneUri = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
                Ringtone ringtone = RingtoneManager.getRingtone(this, ringtoneUri);
                if(ringtoneUri != null){
                    ringtoneUriStr = ringtoneUri.toString();
                    textView_ringToneTitle.setText(ringtone.getTitle(this));
//                    startRingtone(ringUri);
                }else{
                    ringtoneUriStr = "기본값";
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                    textView_ringToneTitle.setText("기본값");
                }
            }
        }
    }

    public void startRingtoneChooseActivity() {
        Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER); // 암시적 Intent

        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Ringtone List"); // 제목을 넣는다
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false); // 무음을 선택 리스트에서 제외
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true); // 기본 벨소리는 선택 리스트에 넣는다.

        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL);

        if(ringtoneUriStr != null && ringtoneUriStr.isEmpty()){
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(ringtoneUriStr));
        }
        this.startActivityForResult(intent, REQUESTCODE_RINGTONE_PICKER);
    }



    /** END OF CODE **/
    /*필요없거나 아직 안쓰는것들. 접어놓으셈!!*/
    private void startRingtone(Uri RingtoneUri){
        this.releaseRingtone();
        try{
            curRingtone = ringtoneManager.getRingtone(this, RingtoneUri);

            if(curRingtone == null){
                throw new Exception("Nothing Choosen");
            }
            curRingtone.play();
        }catch (Exception e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
            Log.e("AlarmSettingActivity", e.getMessage());
            e.printStackTrace();
        }
    }
    private void releaseRingtone(){
        if(curRingtone != null){
            if(curRingtone.isPlaying()){
                curRingtone.stop();
                curRingtone = null;
            }
        }
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopMusic();
    }
    //NumberPicker(횟수) 값 바뀔때마다 최신화?
//        numberPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
//            @Override
//            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
//                picker.setValue(newVal);
//            }
//        });

//    /* 알람 중지 */
//    private void stop() {
//        if (this.pendingIntent == null) {
//            return;
//        }
//        // 알람 취소
//        this.alarmManager.cancel(this.pendingIntent);
//        // 알람 중지 Broadcast
//        Intent intent = new Intent(this, AlarmReceiver.class);
//        intent.putExtra("state","off");
//        sendBroadcast(intent);
//        this.pendingIntent = null;
//    }
}