package com.example.myexercise_01_1c.TRASH;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.myexercise_01.R;
import com.example.myexercise_01_1c.model.Alarm;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class AlarmAdapter extends BaseAdapter {
    private List<Alarm> alarmList;// = ArrayList<AlarmModel>;
    Context context;

//    public AlarmAdapter(List list) {
//        alarmList = list;
//    }
    public AlarmAdapter(Context context, List list) {
        alarmList = list;
        this.context = context;
    }
    @Override
    public int getCount() { //총 아이템의 개수
        return alarmList.size();
    }

    @Override
    public Object getItem(int position) { //포지션번쨰 아이템
//        T adapter = this.getAdapter();
//        return (adapter == null || position < 0) ? null : adapter.getItem(position);
        return alarmList.get(position);
    }

    @Override
    public long getItemId(int position) { //포지션번쨰 아이템의 아이디
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) { //position번쨰 아이템의 view구성하는 부분
        if (convertView == null) {
            //LayoutInflater : 액티비티 이외의 클래스에서 Context를 통해 xml로 정의한 레이아웃을 로드하여 View로 반환하는 클래스
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_time, parent, false);
            // 시간, 요일, View

        }
        TextView textView_time = (TextView)convertView.findViewById(R.id.textView_time);
        TextView textView_day = (TextView)convertView.findViewById(R.id.textView_day);
        //현재 position의 알람 데이터
        Alarm alarmItem = alarmList.get(position);
        //데이터 설정 => 홀더에 저장
//        textView_time.setText(Long.toString(alarmItem.getTIME()));

        SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("h:mm", Locale.getDefault());
        SimpleDateFormat AM_PM_FORMAT = new SimpleDateFormat("a", Locale.getDefault());
//        textView_time.setText(AlarmUtils.getReadableTime(alarm.getTime()));
        String str = TIME_FORMAT.format(alarmItem.getTIME());
        Log.d("zzzzz",str);
        textView_time.setText(str);



//        holder.textView_day.setText("요일..");

        if (alarmItem instanceof CharSequence) {
            textView_day.setText((CharSequence) alarmItem);
        } else {
            textView_day.setText(alarmItem.toString());
        }
        return convertView;
    }
    /* 각 아이템이 화면에 보일 때 호출되는 메서드. 아이템하나하나가 화면에 표시될떄마다 호출됨.
    여기에 표시할 레이아웃과 데이터를 모두 작성해야함 */
//    @Override
//    public View getView(int position, View convertView, ViewGroup parent) { //position번쨰 아이템의 view구성하는 부분
//        ViewHolder holder;
//        if (convertView == null) {
//            holder = new ViewHolder();
//            //LayoutInflater : 액티비티 이외의 클래스에서 Context를 통해 xml로 정의한 레이아웃을 로드하여 View로 반환하는 클래스
//            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_time, parent, false);
//            // 시간, 요일, View
//            holder.textView_time = (TextView)convertView.findViewById(R.id.textView_time);
//            holder.textView_day = (TextView)convertView.findViewById(R.id.textView_day);
//            convertView.setTag(holder);
//        } else {
//            holder = (ViewHolder)convertView.getTag();
//        }
//
//        //현재 position의 알람 데이터
//        AlarmModel alarmItem = alarmList.get(position);
//        //데이터 설정 => 홀더에 저장
//        holder.textView_time.setText(Integer.toString(alarmItem.getTIME()));
////        holder.textView_day.setText("요일..");
//
//        if (alarmItem instanceof CharSequence) {
//            holder.textView_day.setText((CharSequence) alarmItem);
//        } else {
//            holder.textView_day.setText(alarmItem.toString());
//        }
//        return convertView;
//    }
    //뷰홀더 패턴 : 자주 사용하는 뷰를 한번 로드한 뒤로는 그 뷰를 계속 재사용하고 표시할 data만 교체하기 위한 패턴
    static class ViewHolder {
        TextView textView_time;
        TextView textView_day;
    }




}
