package com.example.myexercise_01_1c.util;

public class AlarmUtils {
    public static int getRequestCode(long id) {   // 알람 id값을 주면 리퀘스트 코드 반환
        return (int) (id^(id>>>32));
    }
}
