package com.example.myexercise_01_1c.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.Nullable;

import com.example.myexercise_01_1c.AlarmReceiver;
import com.example.myexercise_01_1c.model.Alarm;
import com.example.myexercise_01_1c.util.AlarmUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    Context context;
    public static final int version = 4;
    public static final String ALARM_TABLE = "ALARM_TABLE";
    public static final String COL_ID = "_id";
    public static final String COL_TIME = "TIME";
    public static final String COL_MON = "MON"; //3
    public static final String COL_TUE = "TUE";
    public static final String COL_WED = "WED";
    public static final String COL_THU = "THU";
    public static final String COL_FRI = "FRI";
    public static final String COL_SAT = "SAT";
    public static final String COL_SUN = "SUN"; //9
    public static final String COL_NAME = "NAME";
    public static final String COL_WORKOUT = "WORKOUT";
    public static final String COL_COUNT = "COUNT";
    public static final String COL_MUSIC = "MUSIC";
    public static final String COL_VOLUME = "VOLUME";
    public static final String COL_ENABLE = "ENABLE";

    private static DBHelper dbHelper = null;
    SQLiteDatabase sqLiteDatabase;

    public static synchronized DBHelper getInstance(Context context) {
        if (dbHelper == null) {
            dbHelper = new DBHelper(context.getApplicationContext());
        }
        return dbHelper;
    }
//    // 테이블 삭제
//    public void dropTable() {
//        mDB.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE+";");
//    }

    public DBHelper(@Nullable Context context) {
        super(context, ALARM_TABLE, null, version);
        this.context = context;
    }
//    public boolean isEnabled() {
////        return Enable;
//    }

    @Override
    public void onCreate(SQLiteDatabase db) {
//        dbHelper = new DBHelper(this.context);
        db.execSQL("DROP TABLE IF EXISTS " + ALARM_TABLE);
        String createTableStatement= "CREATE TABLE " + ALARM_TABLE + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_TIME + " INTEGER NOT NULL, " +
                COL_ENABLE + " INTEGER NOT NULL, " +
                COL_MON + " INTEGER NOT NULL, " +
                COL_TUE + " INTEGER NOT NULL, " +
                COL_WED + " INTEGER NOT NULL, " +
                COL_THU + " INTEGER NOT NULL, " +
                COL_FRI + " INTEGER NOT NULL, " +
                COL_SAT + " INTEGER NOT NULL, " +
                COL_SUN + " INTEGER NOT NULL, " +
                COL_NAME + " TEXT, " +
                COL_WORKOUT + " TEXT, " +
                COL_COUNT + " INTEGER NOT NULL, " +
                COL_MUSIC + " TEXT, " +
                COL_VOLUME + " INTEGER NOT NULL " +
                ");";

        db.execSQL(createTableStatement);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + ALARM_TABLE);
        onCreate(db);
        Log.d("db","onUpgrade() called: " + oldVersion + " / " + newVersion);

//        // 1 -> 2 로 바뀐 경우
//        if(newVersion > 1){
//            String tableName = "customer";
//            db.execSQL("DROP TABLE IF EXISTS " + tableName);
////            println(tableName + " table deleted");
//        }
//        String sql = "DROP TABLE if exists " + ALARM_TABLE;
//
//        db.execSQL(sql);
//        onCreate(db);
    }


    //id값반환하는 메소드로 변경
    public long addAlarm(Alarm alarm){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_TIME, alarm.getTIME());
        cv.put(COL_MON, alarm.getMON());
        cv.put(COL_TUE, alarm.getTUE());
        cv.put(COL_WED, alarm.getWED());
        cv.put(COL_THU, alarm.getTHU());
        cv.put(COL_FRI, alarm.getFRI());
        cv.put(COL_SAT, alarm.getSAT());
        cv.put(COL_SUN, alarm.getSUN());
        cv.put(COL_NAME, alarm.getNAME());
        cv.put(COL_WORKOUT, alarm.getWORKOUT());
        cv.put(COL_COUNT, alarm.getCOUNT());
        cv.put(COL_MUSIC, alarm.getMUSIC().toString());
        cv.put(COL_VOLUME, alarm.getVOLUME());
        cv.put(COL_ENABLE, alarm.getENABLE());
        return db.insert(ALARM_TABLE, null, cv); //id값 반환하는듯
    }
    public boolean deleteAlarm(Alarm alarm) {
        SQLiteDatabase db = this.getWritableDatabase();
        String queryString = "DELETE FROM " + ALARM_TABLE + " WHERE " + COL_ID + " = " + alarm.getID();

        Cursor cursor = db.rawQuery(queryString, null);

        if(cursor.moveToFirst()) return true;
        else return false;
    }
    public boolean deleteIdAlarm(long alarmID) { //id에 해당하는 알람 지우기
        SQLiteDatabase db = this.getWritableDatabase();
        String queryString = "DELETE FROM " + ALARM_TABLE + " WHERE " + COL_ID + " = " + alarmID;
        Cursor cursor = db.rawQuery(queryString, null);

        AlarmReceiver.cancelAlarm(context, AlarmUtils.getRequestCode(alarmID)); //등록된 알람 서비스 해제

        if(cursor.moveToFirst()) return true;
        else return false;
    }

    //알람 enable 여부 변경
    public void changeEnable(Boolean isEnabled) {
        String sqlUpdate = "UPDATE " + ALARM_TABLE + " SET " + COL_ENABLE + "= " + isEnabled;
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL(sqlUpdate);
    }

    public ContentValues mkContentValue(Alarm alarmModel) {
        ContentValues cv = new ContentValues();
        cv.put(COL_TIME, alarmModel.getTIME());
        cv.put(COL_MON, alarmModel.getMON());
        cv.put(COL_TUE, alarmModel.getTUE());
        cv.put(COL_WED, alarmModel.getWED());
        cv.put(COL_THU, alarmModel.getTHU());
        cv.put(COL_FRI, alarmModel.getFRI());
        cv.put(COL_SAT, alarmModel.getSAT());
        cv.put(COL_SUN, alarmModel.getSUN());
        cv.put(COL_NAME, alarmModel.getNAME());
        cv.put(COL_WORKOUT, alarmModel.getWORKOUT());
        cv.put(COL_COUNT, alarmModel.getCOUNT());
        cv.put(COL_MUSIC, alarmModel.getMUSIC().toString());
        cv.put(COL_VOLUME, alarmModel.getVOLUME());
        return cv;
    }

    public int updateAlarm(long alarmID, Alarm alarmModel) {
        final String where = COL_ID + "=?";
        ContentValues cv = mkContentValue(alarmModel);
        final String[] whereArgs = new String[] { Long.toString(alarmID) };
        return getWritableDatabase().update(ALARM_TABLE, cv,where, whereArgs);
    }
    //알람 id값 줬을때 enable 여부 변경
    public void changeEnable(int alarmId, Boolean isEnabled) {
        /*SQLiteDatabase db = this.getWritableDatabase();   //this.getReadableDatabase(); 로 하면 안되더라
//        Cursor cursor;
//        String queryString = "SELECT * FROM " + ALARM_TABLE + " ORDER BY " + COL_ENABLE + " DESC," + COL_TIME + " ASC";
//        cursor = db.rawQuery(queryString, null);
//        return cursor;
        String sqlUpdate2 = "UPDATE " + ALARM_TABLE + " SET " + COL_ENABLE + "= " + isEnabled
                + " WHERE _id" + "=" + alarmId;
        db.execSQL(sqlUpdate2);*/
        SQLiteDatabase db = this.getWritableDatabase();   //this.getReadableDatabase(); 로 하면 안되더라
        final String where = COL_ID + "=?";
        final String[] whereArgs = new String[] { Long.toString(alarmId)};
        ContentValues cv = new ContentValues();
        cv.put(COL_ENABLE, isEnabled);
        db.update(ALARM_TABLE, cv, where, whereArgs);
    }

    //알람 id값 줬을때 enable 여부 변경
    public void changeTime(long curTime, long newTime) {
        SQLiteDatabase db = this.getWritableDatabase();   //this.getReadableDatabase(); 로 하면 안되더라
        final String where = COL_TIME + "=?";
        final String[] whereArgs = new String[] { Long.toString(curTime)};
        ContentValues cv = new ContentValues();
        cv.put(COL_TIME, newTime);
        db.update(ALARM_TABLE, cv, where, whereArgs);
    }


    //커서 반환
    public Cursor getCursor () {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor;
        cursor = db.rawQuery("SELECT * FROM ALARM_TABLE;", null);
        return cursor;
    }
    //시간, enable여부로 정렬한 커서 반환
    public Cursor getCursorInSort () {
        SQLiteDatabase db = this.getWritableDatabase();   //this.getReadableDatabase(); 로 하면 안되더라
        Cursor cursor;
        String queryString = "SELECT * FROM " + ALARM_TABLE + " ORDER BY " + COL_TIME + " ASC"; //시간순으로만 정렬
        //enable여부로도 정렬해서 보여주고싶었는데 괴상한 에러남....
//        String queryString = "SELECT * FROM " + ALARM_TABLE + " ORDER BY " + COL_ENABLE + " DESC," + COL_TIME + " ASC";

        cursor = db.rawQuery(queryString, null);
        return cursor;
    }

    //커서주면 Alarm객체 만들어서 반환/enable빠져있음
    public Alarm getAlarm(Cursor cursor) {
        long _id = cursor.getLong(cursor.getColumnIndex(COL_ID));
        long TIME = cursor.getLong(cursor.getColumnIndex(COL_TIME));
        boolean MON = cursor.getInt(cursor.getColumnIndex("MON")) == 1 ? true : false ;
        boolean TUE = cursor.getInt(cursor.getColumnIndex("TUE")) == 1 ? true : false ;
        boolean WED = cursor.getInt(cursor.getColumnIndex("WED")) == 1 ? true : false ;
        boolean THU = cursor.getInt(cursor.getColumnIndex("THU")) == 1 ? true : false ;
        boolean FRI = cursor.getInt(cursor.getColumnIndex("FRI")) == 1 ? true : false ;
        boolean SAT = cursor.getInt(cursor.getColumnIndex("SAT")) == 1 ? true : false ;
        boolean SUN = cursor.getInt(cursor.getColumnIndex("SUN")) == 1 ? true : false ;
        String NAME = cursor.getString(cursor.getColumnIndex(COL_NAME));
        String EXER = cursor.getString(cursor.getColumnIndex(COL_WORKOUT));
        int COUNT = cursor.getInt(cursor.getColumnIndex(COL_COUNT));
        String MUSIC = cursor.getString(cursor.getColumnIndex(COL_MUSIC));
        int VOLUME = cursor.getInt(cursor.getColumnIndex(COL_VOLUME));
        Alarm newAlarm = new Alarm(_id, TIME ,MON, TUE, WED, THU, FRI, SAT, SUN, NAME, EXER, COUNT, MUSIC, VOLUME);

        return newAlarm;
    }
    //id주면 Alarm객체 만들어서 반환/enable빠져있음
    public Alarm getAlarm(long alarmId) {
        SQLiteDatabase db = this.getWritableDatabase();   //this.getReadableDatabase(); 로 하면 안되더라
        String queryString = "SELECT * FROM " + ALARM_TABLE + " WHERE " + COL_ID + " = " + alarmId;
        Cursor cursor = db.rawQuery(queryString, null);
        cursor.moveToFirst();
        long _id = cursor.getLong(cursor.getColumnIndex(COL_ID));
        long TIME = cursor.getLong(cursor.getColumnIndex(COL_TIME));
        boolean MON = cursor.getInt(cursor.getColumnIndex("MON")) == 1 ? true : false ;
        boolean TUE = cursor.getInt(cursor.getColumnIndex("TUE")) == 1 ? true : false ;
        boolean WED = cursor.getInt(cursor.getColumnIndex("WED")) == 1 ? true : false ;
        boolean THU = cursor.getInt(cursor.getColumnIndex("THU")) == 1 ? true : false ;
        boolean FRI = cursor.getInt(cursor.getColumnIndex("FRI")) == 1 ? true : false ;
        boolean SAT = cursor.getInt(cursor.getColumnIndex("SAT")) == 1 ? true : false ;
        boolean SUN = cursor.getInt(cursor.getColumnIndex("SUN")) == 1 ? true : false ;
        String NAME = cursor.getString(cursor.getColumnIndex(COL_NAME));
        String EXER = cursor.getString(cursor.getColumnIndex(COL_WORKOUT));
        int COUNT = cursor.getInt(cursor.getColumnIndex(COL_COUNT));
        String MUSIC = cursor.getString(cursor.getColumnIndex(COL_MUSIC));
        int VOLUME = cursor.getInt(cursor.getColumnIndex(COL_VOLUME));
        Alarm newAlarm = new Alarm(_id, TIME ,MON, TUE, WED, THU, FRI, SAT, SUN, NAME, EXER, COUNT, MUSIC, VOLUME);
        return newAlarm;
    }
    /** END OF CODE **/
    /*public List<Alarm> getAlarmList() {   //안쓰니까
        List<Alarm> AlarmList = new ArrayList<Alarm>();
        String queryString ="SELECT * FROM " + ALARM_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);

        if(cursor.moveToFirst()) {
            do {
                int _id = cursor.getInt(0);
//                int _id = cursor.getInt(cursor.getColumnIndex("_id"));
                long TIME = cursor.getLong(1);
                boolean MON = cursor.getInt(cursor.getColumnIndex("MON")) == 1 ? true : false ;
                boolean TUE = cursor.getInt(cursor.getColumnIndex("TUE")) == 1 ? true : false ;
                boolean WED = cursor.getInt(cursor.getColumnIndex("WED")) == 1 ? true : false ;
                boolean THU = cursor.getInt(cursor.getColumnIndex("THU")) == 1 ? true : false ;
                boolean FRI = cursor.getInt(cursor.getColumnIndex("FRI")) == 1 ? true : false ;
                boolean SAT = cursor.getInt(cursor.getColumnIndex("SAT")) == 1 ? true : false ;
                boolean SUN = cursor.getInt(cursor.getColumnIndex("SUN")) == 1 ? true : false ;
                Alarm newAlarm = new Alarm(_id, TIME ,MON, TUE, WED, THU, FRI, SAT, SUN);
                AlarmList.add(newAlarm);
            } while(cursor.moveToNext());
        }
        else {
        }
        Comparator<Alarm> myComparator = new Comparator<Alarm>() {
            @Override
            public int compare(Alarm o1, Alarm o2) {
                if(o1.getTIME() > o2.getTIME()) return 1;
                else if(o1.getTIME() == o2.getTIME()) return 1;
                return -1;
            }
        };
        Collections.sort(AlarmList, myComparator);

        cursor.close();
        db.close();
        return AlarmList;
    }*/

    //기존 덕진이 ok 반환하는 메소드
//    public boolean addAlarm(Alarm alarm){
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues cv = new ContentValues();
//        cv.put(COL_TIME, alarm.getTIME());
//        cv.put(COL_MON, alarm.getMON());
//        cv.put(COL_TUE, alarm.getTUE());
//        cv.put(COL_WED, alarm.getWED());
//        cv.put(COL_THU, alarm.getTHU());
//        cv.put(COL_FRI, alarm.getFRI());
//        cv.put(COL_SAT, alarm.getSAT());
//        cv.put(COL_SUN, alarm.getSUN());
//        cv.put(COL_NAME, alarm.getNAME());
//        cv.put(COL_WORKOUT, alarm.getWORKOUT());
//        cv.put(COL_COUNT, alarm.getCOUNT());
//        cv.put(COL_MUSIC, alarm.getMUSIC());
//        cv.put(COL_VOLUME, alarm.getVOLUME());
//        cv.put(COL_ENABLE, alarm.getENABLE());
//        db.insert(ALARM_TABLE, null, cv);
//        return true;
//    }
}
