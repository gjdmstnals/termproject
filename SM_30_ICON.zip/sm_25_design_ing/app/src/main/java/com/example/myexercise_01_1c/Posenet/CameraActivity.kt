/*
 * Copyright 2019 The TensorFlow Authors. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.myexercise_01_1c.Posenet

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.FragmentActivity
import com.example.myexercise_01.R
import kotlinx.android.synthetic.main.tfe_pn_activity_camera.*

class CameraActivity : AppCompatActivity(),
        PosenetActivity.PosenetFinishedListener,
        RandomPoseActivity.RandomPoseFinishedListener {
  var TAG = "클래스"+javaClass.simpleName
  var missionName : String? = null //null이 될 수 있는 변수란 뜻.
  var missionCount : Int = 0

  override fun onStart() {
    super.onStart()
    Log.d(TAG, "onStart")
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    Log.d(TAG, "onCreate")
    super.onCreate(savedInstanceState)
    setContentView(R.layout.tfe_pn_activity_camera)

    //디버깅용
    if (intent == null)       Log.d(TAG, "intent가 널")
    else                      Log.d(TAG, "intent가 널 아님")

    missionName = intent.getStringExtra("missionName")
    missionCount = intent.getIntExtra("missionCount", 0)

    Log.e(TAG + "미션명", missionName.toString())

    //view init
    textView_missionName.setText(missionName)
//    textView_missionCount.setText(missionCount.toString())
    //
    if (missionName == "null" || missionCount == 0) {
      Log.e(TAG + "미션명 널임", missionName.toString())
      finishCameraActivity()
    }

    // 미션 받아서 전달할 번들 생성
    var bundle = Bundle()
    bundle.putString("missionName", missionName)
    bundle.putInt("missionCount", missionCount)
    if(missionName == "Squat") {
      var poseNetAct = PosenetActivity()
      poseNetAct.arguments = bundle


      window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) //앱이 실행될때 화면을 켜놓기 위함
      savedInstanceState ?: supportFragmentManager.beginTransaction()
              .replace(R.id.container, poseNetAct)      //.replace(R.id.container, PosenetActivity())
              .commit()
    }
    if(missionName == "Random Pose"){
      var randomAct = RandomPoseActivity()
      randomAct.arguments = bundle

      window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) //앱이 실행될때 화면을 켜놓기 위함
      savedInstanceState ?: supportFragmentManager.beginTransaction()
              .replace(R.id.container, randomAct)      //.replace(R.id.container, PosenetActivity())
              .commit()
    }

  }
  var flagEnd = false

  //액티비티 종료하기 위한 함수
  fun finishCameraActivity() {
    flagEnd = true
    setResult(RESULT_OK)
    finish()
  }
  //포즈넷 액티비티 종료시 호출됨
  override fun onPosenetFinished() {
    Log.e(TAG, "onPosenetFinished호출")
    finishCameraActivity()
  }

  override fun onRandomPoseFinished(){
    Log.e(TAG, "onRandomPoseFinished호출")
    finishCameraActivity()
  }

  //뒤로가기 막기
  override fun onBackPressed() {
  //        super.onBackPressed(); // 기존 뒤로 가기 버튼의 기능을 막기 위해 주석 처리 또는 삭제
  }

  // 홈키, 메뉴키 재실행 방식으로 막기
  var onStopTime: Long = 0
  override fun onStop() {
    super.onStop()
    if (!flagEnd  && System.currentTimeMillis() > onStopTime + 1000) {         //1초를 더함
      onStopTime = System.currentTimeMillis() //
      Log.e(TAG + "미션명", missionName.toString())
      var intent = Intent (this, CameraActivity::class.java)
      intent.putExtra("missionName", missionName)
      intent.putExtra("missionCount", missionCount)
      startActivity(intent)     //startActivity(Intent(this, CameraActivity::class.java))

      Toast.makeText(this, "재실행", Toast.LENGTH_SHORT).show()
    }
  }

  override fun onDestroy() {
    super.onDestroy()
    Log.d(TAG, "onDestroy")
  }
  /** END OF CODE **/
}