package com.example.myexercise_01_1c.TRASH;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.widget.Toast;

import com.example.myexercise_01_1c.AlarmReceiver;
import com.example.myexercise_01_1c.AlarmRingingActivity;
import com.example.myexercise_01_1c.model.Alarm;
import com.example.myexercise_01_1c.util.TimeUtils;

import java.util.Calendar;

import static android.app.PendingIntent.FLAG_UPDATE_CURRENT;

public class AlarmReceiver2 extends BroadcastReceiver {
    Context context;
    //방송이 수신되면 자동으로 호출되는 콜백메서드, 각 방송 정보는 intent로 전달됨 Intent
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(getClass().getSimpleName(), "onReceive");
        //디버깅용
        String str = "알람onReceive: " + intent.getStringExtra("time");
        boolean week[] = { false, intent.getBooleanExtra("sun", true), intent.getBooleanExtra("mon", true),
                intent.getBooleanExtra("tue", true), intent.getBooleanExtra("wed", true),
                intent.getBooleanExtra("thu", true), intent.getBooleanExtra("fri", true),
                intent.getBooleanExtra("sat", true)};
        Calendar cal = Calendar.getInstance();
        if(!week[cal.get(Calendar.DAY_OF_WEEK)])
        {
            return;
        }
        Toast.makeText(context, str, Toast.LENGTH_SHORT).show();
        //디버깅용

//        Intent sIntent = new Intent(context, AlarmService.class);
//        sIntent.putExtra("state", intent.getStringExtra("state"));
//
//        // Oreo(26) 버전 이후부터는 Background 에서 실행을 금지하기 때문에 Foreground 에서 실행해야 함
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            context.startForegroundService(sIntent);
//        } else {
//            context.startService(sIntent);
//        }
//my code
//        Intent activityIntent = new Intent(context.getApplicationContext(), AlarmRingingActivity.class);
//        //activityIntent.putExtra("state", intent.getStringExtra("state"));
//        //activityIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        activityIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
//        context.startActivity(activityIntent);

//        //Alarm Ringing Activity 수행
        Intent i = new Intent(context, AlarmRingingActivity.class);
        i.putExtra("state", intent.getStringExtra("state"));
        Uri temp = intent.getParcelableExtra("music");
        i.putExtra("music", temp);
        i.putExtra("volume", intent.getIntExtra("volume", 0));
        //미션 종류, 횟수 테스트
        i.putExtra("missionName", intent.getStringExtra("missionName"));
        i.putExtra("missionCount", intent.getIntExtra("missionCount", 0));

        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
//        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK); //는 안되더라
//        i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP |
//                Intent.FLAG_ACTIVITY_NEW_TASK |
//                Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);

        context.startActivity(i); //디버깅 - 임시로 닫아놓음 원래 열어놔야함
    }

    public static void cancelAlarm(Context context, Alarm alarm) {
        final Intent intent = new Intent(context, AlarmReceiver.class);
        final PendingIntent pIntent = PendingIntent.getBroadcast(
                context, alarm.getRequestCode(), intent, FLAG_UPDATE_CURRENT);

        final AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Toast.makeText(context, "알람이 해지되었습니다", Toast.LENGTH_SHORT).show();
        manager.cancel(pIntent);

        TimeUtils.printTimeStringDebug("알람서비스해지", alarm.getTIME());
    }
    public static void cancelAlarm(Context context, int requestcode) {
        final Intent intent = new Intent(context, AlarmReceiver.class);
        final PendingIntent pIntent = PendingIntent.getBroadcast(
                context, requestcode, intent, FLAG_UPDATE_CURRENT);

        final AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Toast.makeText(context, "알람이 해지되었습니다", Toast.LENGTH_SHORT).show();

        manager.cancel(pIntent);

    }
    public static void registerAlarm(Context context, Alarm alarm) {
        final Intent intent = new Intent(context, AlarmReceiver.class); // Receiver 설정
        intent.putExtra("time", TimeUtils.getTimeStringDebug(alarm.getTIME())); //디버깅용
        intent.putExtra("mon", alarm.getMON());
        intent.putExtra("tue", alarm.getTUE());
        intent.putExtra("wed", alarm.getWED());
        intent.putExtra("thu", alarm.getTHU());
        intent.putExtra("fri", alarm.getFRI());
        intent.putExtra("sat", alarm.getSAT());
        intent.putExtra("sun", alarm.getSUN());
        intent.putExtra("music", alarm.getMUSIC());
        intent.putExtra("volume", alarm.getVOLUME());
        //브로드캐스트 발송하는 펜딩인덴트에 들어가는 인텐트에 미션종류, 횟수 추가
        intent.putExtra("missionName", alarm.getWORKOUT());
        intent.putExtra("missionCount", alarm.getCOUNT());


        //브로드캐스트 발송하는 펜딩인덴트
        /* receiver를 동작하게 하기 위해 PendingIntent의 인스턴스를 생성할 때, getBroadcast 라는 메소드를 사용함.
        requestCode는 나중에 Alarm을 해제 할때 어떤 Alarm을 해제할지를 식별하는 코드 */
        final PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context, alarm.getRequestCode(), intent, FLAG_UPDATE_CURRENT);


        final AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        /* 설정된 시각에 알람 설정
        인자 : 알람매니저 타입 / 언제 이 알람이 발동되야하는지 그 시간을 long값으로 줘야함 / 뭐가 실행될지는 펜딩인덴트로 동작하게 함. */
        manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, alarm.getTIME(), pendingIntent); //setExact()과 동일하만 절전모드에서도 동작하는 함수
        //        alarmManager.setAlarmClock(AlarmManager.RTC_WAKEUP, time.getTimeInMillis(), pendingIntent); //setExact()과 동일하지만 절전모드에서도 동작하는 함수
        Toast.makeText(context, "알람이 설정되었습니다", Toast.LENGTH_SHORT).show();

        TimeUtils.printTimeStringDebug("알람서비스등록", alarm.getTIME());
    }
}
