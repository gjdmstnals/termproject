package com.example.myexercise_01_1c.db;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.widget.SwitchCompat;

import com.example.myexercise_01.R;
import com.example.myexercise_01_1c.AlarmReceiver;
import com.example.myexercise_01_1c.model.Alarm;
import com.example.myexercise_01_1c.model.CheckedItem;
import com.example.myexercise_01_1c.util.TimeUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;

import static com.example.myexercise_01_1c.db.DBHelper.COL_WORKOUT;

public class AlarmCursorAdapter extends CursorAdapter  {
    Activity activity;

    private LayoutInflater mInflater;
    DBHelper dbHelper;
    Context mContext;

    ArrayList<Integer> enabledListItem;
    ArrayList<CheckedItem> checkedItemList;

    private Drawable drawableList[] = new Drawable[4];

    /**
     * 커서 어댑터의 여러가지 생성자 중 가장 많이 사용되는 생성자 입니다.
     * @param context : 컨텍스트
     * @param c : 데이터로 사용할 커서 객체
     * @param autoRequery : false
     */
    public AlarmCursorAdapter(Context context, Cursor c, boolean autoRequery) {
        super(context, c, autoRequery);
        dbHelper = DBHelper.getInstance(context);
        mInflater = LayoutInflater.from(context);
        mContext = context;

//        enabledListItem = new ArrayList();
//        checkedItemList = new ArrayList<>(30); //실질적으로 30개공간을잡아놓는것은아님
//        for (int i = 0; i < 30; i++) {
//            checkedItemList.add(new CheckedItem());
//        }
    }
//    public AlarmCursorAdapter(Activity activity, Context context, Cursor c, boolean autoRequery ) {
//        super(context, c, autoRequery);
//        dbHelper = DBHelper.getInstance(context);
//        mInflater = LayoutInflater.from(context);
//        this.activity = activity;
////        activity = context.getA
//    }

    //뷰를 생성
    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        ViewHolder viewHolder = new ViewHolder();

        View view = mInflater.inflate(R.layout.item_time, parent, false);
        viewHolder.textView_time = (TextView) view.findViewById(R.id.textView_time);
        viewHolder.textView_ampm = (TextView) view.findViewById(R.id.textView_ampm);
        viewHolder.textView_day = (TextView) view.findViewById(R.id.textView_day);
        viewHolder.imageView_mission = (ImageView) view.findViewById(R.id.imageView_mission);
        viewHolder.switch_enable = (SwitchCompat) view.findViewById(R.id.switch_enable);

        drawableList[0] = (Drawable) context.getResources().getDrawable(R.drawable.icon_mission_squat, null);
        drawableList[1] = (Drawable) context.getResources().getDrawable(R.drawable.icon_mission_random, null);
        drawableList[2] = (Drawable) context.getResources().getDrawable(R.drawable.icon_mission_none, null);


        view.setTag(viewHolder);

        return view;
    }

    //뷰 바인딩
    @Override
    public void bindView(View view, Context context, Cursor cursor) { //newView에서 리턴한 녀석이 날라옴
        ViewHolder viewHolder = (ViewHolder) view.getTag();

        long time = cursor.getLong(cursor.getColumnIndex("TIME"));
        //시간 출력
//        String timeStr = TimeUtils.TIME_FORMAT.format(time);
//        viewHolder.textView_time.setText(timeStr);

        //미션 이미지 설정
        String EXER = cursor.getString(cursor.getColumnIndex(COL_WORKOUT));
        int index = 0;
        if (EXER == null) {
            index = 2;
        } else if (EXER.equals("Squat")) {
            index = 0;
        } else if (EXER.equals("Random Pose")) {
            index = 1;
        }
//        if (EXER == null) index = 2;
//        else {
//        switch (EXER) {
//            case "Squat" :
//                index = 0;
//                break;
//            case "Random Pose" :
//                index = 1;
//                break;
//            default:
//                index = 2;
//        }}
        viewHolder.imageView_mission.setImageDrawable(drawableList[index]);

        //시간, AM PM 출력
        viewHolder.textView_time.setText(TimeUtils.TIME_FORMAT.format(time));// + "/ "+ cursor.getLong(cursor.getColumnIndex("TIME")));
        viewHolder.textView_ampm.setText(TimeUtils.AM_PM_FORMAT.format(time));

        //요일 출력
        StringBuilder sb = new StringBuilder("");
        sb.append(cursor.getInt(cursor.getColumnIndex("MON")) == 1 ? "월 " : "") ;
        sb.append(cursor.getInt(cursor.getColumnIndex("TUE")) == 1 ? "화 " : "") ;
        sb.append(cursor.getInt(cursor.getColumnIndex("WED")) == 1 ? "수 " : "") ;
        sb.append(cursor.getInt(cursor.getColumnIndex("THU")) == 1 ? "목 " : "") ;
        sb.append(cursor.getInt(cursor.getColumnIndex("FRI")) == 1 ? "금 " : "") ;
        sb.append(cursor.getInt(cursor.getColumnIndex("SAT")) == 1 ? "토 " : "") ;
        sb.append(cursor.getInt(cursor.getColumnIndex("SUN")) == 1 ? "일 " : "") ;
        viewHolder.textView_day.setText(sb.toString());

//        //디버깅용 -- 나중에 지울 부분
//        String str = TimeUtils.DEBUG_DATE_FORMAT.format(time);
//        str += "_id: " + cursor.getInt(cursor.getColumnIndex("_id")) + "/" + sb.toString();
//        viewHolder.textView_day.setText(str);
//        //디버깅용 --

        final int position = cursor.getPosition();     //맞는값출력됨
        Cursor myCursor = (Cursor) getItem(position);
        boolean isEnabled = myCursor.getInt(myCursor.getColumnIndex("ENABLE")) == 1;
        if (isEnabled == true)   viewHolder.switch_enable.setChecked(true);     //db의 enable여부에 따라 switch버튼 체크
        else if (isEnabled == false) viewHolder.switch_enable.setChecked(false);

        viewHolder.switch_enable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("zzzd3, position", String.valueOf(position));
                Cursor myCursor = (Cursor) getItem(position);
                int id = myCursor.getInt(myCursor.getColumnIndex("_id"));
                Alarm alarm = dbHelper.getAlarm(myCursor);
                Log.d("선택된아이템의 id값 :", String.valueOf(id));
                boolean isEnabled = myCursor.getInt(myCursor.getColumnIndex("ENABLE")) == 1;
                boolean isChecked = viewHolder.switch_enable.isChecked(); //클릭해서 바뀐 enable값 가짐
                if (isChecked) { //스위치 켜졌으면 알람 서비스 등록
                    Log.d("ㅋㅋㅋ스위치켜짐, id값",String.valueOf(id));
                    dbHelper.changeEnable(id, true);
                    AlarmReceiver.registerAlarm(context, alarm);    //
                } else if (!isChecked) { //스위치 꺼졌으면 알람 서비스 해제
                    dbHelper.changeEnable(id, false);
                    Log.d("ㅋㅋㅋ스위치꺼짐, id값",String.valueOf(id));
                    AlarmReceiver.cancelAlarm(context, alarm);
                }
                //notifyDataSetChanged(); //데이터변경됐다고 알려주는 메서드..추가해도뭐가바뀌진않음. 아래를 추가해줘야함 글고 이거추가하면 스위치값안바뀜
                changeCursor(dbHelper.getCursorInSort()); //커서변경 안하면 예전 db값을 참고하는 커서를 갖고있음
            }
        });
    }
    static class ViewHolder {
        TextView textView_time;
        TextView textView_ampm;
        TextView textView_day;
        ImageView imageView_mission;
        SwitchCompat switch_enable;
    }
}
