package com.example.myexercise_01_1c.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;

import com.example.myexercise_01_1c.AlarmReceiver;
import com.example.myexercise_01_1c.db.DBHelper;
import com.example.myexercise_01_1c.model.Alarm;

import static android.content.Intent.ACTION_BOOT_COMPLETED;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            Cursor c = null;
            c = DBHelper.getInstance(context).getReadableDatabase().query("ALARM_TABLE", null, null, null, null, null, null);
            if (c == null) return;
            if (c.moveToFirst()) {
                do {
                    if (c.getInt(c.getColumnIndex("ENABLE")) == 1 ? true : false) {
                        long id = c.getLong(c.getColumnIndex("_id"));
                        long time = c.getLong(c.getColumnIndex("TIME"));
                        boolean mon = c.getInt(c.getColumnIndex("MON")) == 1 ? true : false;
                        boolean tue = c.getInt(c.getColumnIndex("TUE")) == 1 ? true : false;
                        boolean wed = c.getInt(c.getColumnIndex("WED")) == 1 ? true : false;
                        boolean thu = c.getInt(c.getColumnIndex("THU")) == 1 ? true : false;
                        boolean fri = c.getInt(c.getColumnIndex("FRI")) == 1 ? true : false;
                        boolean sat = c.getInt(c.getColumnIndex("SAT")) == 1 ? true : false;
                        boolean sun = c.getInt(c.getColumnIndex("SUN")) == 1 ? true : false;
                        String name = c.getString(c.getColumnIndex("NAME"));
                        String music = c.getString(c.getColumnIndex("MUSIC"));
                        String workout = c.getString(c.getColumnIndex("WORKOUT"));
                        int count = c.getInt(c.getColumnIndex("COUNT"));
                        int volume = c.getInt(c.getColumnIndex("VOLUME"));
                        Alarm alarm = new Alarm(id, time, mon, tue, wed, thu, fri, sat, sun, name, workout, count, music, volume);
                        AlarmReceiver.registerAlarm(context, alarm);
                    } else continue;
                } while (c.moveToNext());
            }
            /* Executors.newSingleThreadExecutor().execute(() -> {
                final List<Alarm> alarms = DBHelper.getInstance(context).getAllAlarm();
                //AlarmReceiver.registerAlarm(context, alarms);
                for(int i = 0; i < alarms.size(); i++) {
                    if(alarms.get(i).getENABLE() == true) {
                        AlarmReceiver.registerAlarm(context, alarms.get(i));
                    }
                }
            });*/
            // }
        }
    }
}