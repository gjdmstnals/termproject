package com.example.myexercise_01_1c.util;

import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Locale;

public class TimeUtils {
    public static final SimpleDateFormat TIME_FORMAT
            = new SimpleDateFormat("hh:mm", Locale.getDefault()); //오전 1:04
    public static final SimpleDateFormat DEBUG_DATE_FORMAT
            = new SimpleDateFormat("M월d일(E)", Locale.getDefault()); //5월21일(수)
    public static final SimpleDateFormat DEBUG_DATE_TIME_FORMAT
            = new SimpleDateFormat("M월d일(E)a hh:mm ", Locale.getDefault()); //5월21일(수)
    public static final SimpleDateFormat AM_PM_FORMAT =
            new SimpleDateFormat("a", Locale.getDefault()); //오전

    public static void printTimeStringDebug(String methodName, long time) {
        String str = methodName + " 시간값(포멧팅): "+TimeUtils.TIME_FORMAT.format(time);
        Log.d("ㅋㅋㅋ", str);
        Log.d("ㅋㅋㅋ", String.valueOf(time));
        Log.d("ㅋㅋㅋ", "---------------------------------------------------------");
    }
    public static void printTimeStringDebug(String methodName, long curTime, long newTime) {
        String str1 = methodName + " 예전 시간값: " + TimeUtils.DEBUG_DATE_TIME_FORMAT.format(curTime);
        String str2 = methodName + " 새 시간값: " + TimeUtils.DEBUG_DATE_TIME_FORMAT.format(newTime);
        Log.d("ㅋㅋㅋ", str1);
        Log.d("ㅋㅋㅋ", str2);
        Log.d("ㅋㅋㅋ", "---------------------------------------------------------");

    }
    public static void printTimeStringDebug(String methodName, long time, int requestCode) {
        String str = methodName + " 시간값(포멧팅): "+TimeUtils.TIME_FORMAT.format(time) + ", 리퀘코드: " + requestCode;
        Log.d("ㅋㅋㅋ", str);
        Log.d("ㅋㅋㅋ", String.valueOf(time));
        Log.d("ㅋㅋㅋ", "---------------------------------------------------------");
    }
    public static String getTimeStringDebug(long time) {
        String str = " 시간값(포멧팅): "+TimeUtils.TIME_FORMAT.format(time);
        return str;
    }



}
