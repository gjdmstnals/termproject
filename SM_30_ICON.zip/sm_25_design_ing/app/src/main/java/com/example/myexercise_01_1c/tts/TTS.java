package com.example.myexercise_01_1c.tts;

import android.content.Context;
import android.media.MediaPlayer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Log;
import android.widget.Toast;

import java.io.Serializable;
import java.util.Locale;

public class TTS implements Serializable {
    private static final String TAG = "클래스"+TTS.class.getSimpleName();
    private static TextToSpeech textToSpeech;
    static Context context;
    public static volatile int flagInit = 0;

    //    public static void initTts(Context context) {
//        textToSpeech = new TextToSpeech(context, new TextToSpeech.OnInitListener() {
//            @Override
//            public void onInit(int status) {
//                if(status != TextToSpeech.ERROR) {
//                    int result = textToSpeech.setLanguage(Locale.KOREA); //한국어로 설정
//                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
//                        Toast.makeText(context, "This language is not supported!",  Toast.LENGTH_SHORT);
//                    } else { // 준비 완료
//                        flagInit = 1;
//
//
//
//                    }
//                }
//            }
//        });
//    }
    public TTS(Context context, String missionName, int missionCount) {

        // TTS를 생성하고 OnInitListener로 초기화 한다.
        textToSpeech = new TextToSpeech(context, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status != TextToSpeech.ERROR) {
                    int result = textToSpeech.setLanguage(Locale.KOREA); //한국어로 설정
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Toast.makeText(context, "This language is not supported!",  Toast.LENGTH_SHORT);
                    } else { // 준비 완료
                        flagInit = 1;
                        speakStart(missionName, missionCount);
                    }
                }
            }
        });
        textToSpeech.setOnUtteranceProgressListener(progressListener); //없어도 됨..
        this.context = context;
    }

//    public TTS(Context context) {
//        // TTS를 생성하고 OnInitListener로 초기화 한다.
//        textToSpeech = new TextToSpeech(context, new TextToSpeech.OnInitListener() {
//            @Override
//            public void onInit(int status) {
//                if(status != TextToSpeech.ERROR) {
//                    int result = textToSpeech.setLanguage(Locale.KOREA); //한국어로 설정
//                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
//                        Toast.makeText(context, "This language is not supported!",  Toast.LENGTH_SHORT);
//                    } else { // 준비 완료
//                        flagInit = 1;
//                        speakStart(missionName, missionCount);
//
//
//
//                    }
//                }
//            }
//        });
//        textToSpeech.setOnUtteranceProgressListener(progressListener); //없어도 됨..
//        this.context = context;
//    }

    public static void speakStart(String mission, int number) {
//        AudioManager audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

//        while (flagInit == 0) {}
        if (flagInit == 1) {
            String str = mission + "기상미션을 시작합니다. 횟수" + number + "번 입니다. 카메라를 준비하세요";
            textToSpeech.speak(str, TextToSpeech.QUEUE_FLUSH, null, null);
            Toast.makeText(context, "speakStart실행", Toast.LENGTH_SHORT).show();
        } else {
            Log.d(TAG, "아직 준비안됐서");
        }
    }
    public void speakTimes(int number) {
//        while (flagInit == 0) {}
        if (number == 0) {
            speakEnd();
            while (isSpeaking()) {}
            ttsShutdown();
//            return;
        } else {
            String str = number + "회 남았습니다.";
            textToSpeech.speak(str, TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }
    public void speakEnd() {
//        while (flagInit == 0) {}
        String str = "알람을 종료합니다.";
        textToSpeech.speak(str, TextToSpeech.QUEUE_FLUSH, null, null);
    }
    public void speakNotCorrect() {
        String str = "자세가 바르지 않습니다.";
        textToSpeech.speak(str, TextToSpeech.QUEUE_FLUSH, null, null);
    }

    public void stop() {
        textToSpeech.stop();
    }

    public void shutdown() {
        textToSpeech.shutdown();
    }

    public boolean isSpeaking() {
        return textToSpeech.isSpeaking();
    }

    public void ttsShutdown() { //종료전에 호출해야함
        if(textToSpeech != null && textToSpeech.isSpeaking()) {
            textToSpeech.stop();
        }
        if(textToSpeech != null) {
            textToSpeech.shutdown();
        }
        textToSpeech = null;
    }

    /*음성 재생 상태에 대한 callback을 받을 수 있는 추상 클래스.. 없어도 됨
     'utteranceID'는 단어 그대로 현재 재생중인 음성에 대한 ID값을 나타낸다.
     여러 개의 음성을 컨트롤할 때 유용하게 사용될 것 같다. */
    private UtteranceProgressListener progressListener = new UtteranceProgressListener() {
        @Override
        public void onStart(String utteranceId) { // 음성이 재생되었을 때
            Log.d(TAG, "onStart / utteranceID = " + utteranceId);
        }

        @Override
        public void onDone(String utteranceId) { // 제공된 텍스트를 모두 음성으로 재생한 경우
            Log.d(TAG, "onDone / utteranceID = " + utteranceId);
        }
        @Override
        public void onError(String utteranceId) { // ERROR!
            Log.d(TAG, "onError / utteranceID = " + utteranceId);
        }
    };

}