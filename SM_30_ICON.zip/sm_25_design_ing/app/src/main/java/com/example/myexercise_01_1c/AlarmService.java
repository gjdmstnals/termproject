package com.example.myexercise_01_1c;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;

import android.app.Service;
import android.content.Context;
import android.content.Intent;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import com.example.myexercise_01.R;

public class AlarmService extends Service {
    private MediaPlayer mediaPlayer = new MediaPlayer();
    AudioManager audio;
    int curvolume;
    private String TAG = "클래스"+getClass().getSimpleName();

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Foreground 에서 실행되면 Notification 을 보여줘야 됨
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Oreo(26) 버전 이후 버전부터는 channel 이 필요함
            String channelId =  createNotificationChannel();

            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channelId);
            Notification notification = builder.setOngoing(true)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    //.setCategory(Notification.CATEGORY_SERVICE)
                    .build();

            startForeground(1, notification);
        }

        Uri ringtone = intent.getParcelableExtra("music");
        Log.d(TAG, String.valueOf(ringtone));
        int volume = intent.getIntExtra("volume", 0);
        playMusic(ringtone, volume);

//        String state = intent.getStringExtra("state");

//        if (!isRunning && state.equals("on")) {           // 알람음 재생 OFF, 알람음 시작 상태
//            mediaPlayer = MediaPlayer.create(this, R.raw.alarm);
//            mediaPlayer.setLooping(true); //음악 반복재생
//            mediaPlayer.start();
//
//            isRunning = true;
//
//            Log.d("AlarmService", "Alarm Start");
//        } else if (isRunning & state.equals("off")) {     // 알람음 재생 ON, 알람음 중지 상태
//
//            mediaPlayer.stop(); //재생중지
//            mediaPlayer.reset();
//            mediaPlayer.release(); //미디어플레이어 리소스 해제
//
//            isRunning = false;
//
//            Log.d("AlarmService", "Alarm Stop");
//
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                stopForeground(true);
//            }
//        }
        return START_NOT_STICKY;
    }
    private void playMusic(Uri uri, int volume) {
        stopMusic();  // 플레이 할 때 가장 먼저 음악 중지 실행, 자원 효율성
        try {
            Log.d("AlarmService", "Alarm try");
            audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
//            curvolume = audio.getStreamVolume(AudioManager.STREAM_MUSIC);
            mediaPlayer = MediaPlayer.create(this, uri);
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, volume, 0);
            startAlarm(mediaPlayer);
//            mediaPlayer.setLooping(true);    // 음악 반복 재생
//            player.prepare();   // 3. 재생 준비 .. 블로그에있던건데 난 이거있음 오히려 에러남
//            mediaPlayer.start();    // 4. 재생 시작
        } catch (Exception ex) {
            try {
                Log.d("AlarmService", "Alarm catch try");

                mediaPlayer.reset();    // MediaPlayer의 Error 상태 초기화
                mediaPlayer = MediaPlayer.create(this, R.raw.alarm);
                audio.setStreamVolume(AudioManager.STREAM_MUSIC, volume, 0);
                startAlarm(mediaPlayer);
            } catch (Exception ex2) {
                Log.d("AlarmService", "Alarm catch catch");

                ex2.printStackTrace();
            }
        }
    }
    private void startAlarm(MediaPlayer player) throws java.io.IOException, IllegalArgumentException, IllegalStateException {
        Log.d("AlarmService", "Alarm Start");
//        final AudioManager audioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
//        if (audioManager.getStreamVolume(AudioManager.STREAM_ALARM) != 0) {   // 현재 Alarm 볼륨 구함
//            player.setAudioStreamType(AudioManager.STREAM_ALARM);    // Alarm 볼륨 설정
            player.setLooping(true);    // 음악 반복 재생
////            player.prepare();   // 3. 재생 준비 .. 블로그에있던건데 난 이거있음 오히려 에러남
            player.start();    // 4. 재생 시작
////        }
//        player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
//            @Override
//            public void onPrepared(MediaPlayer mp) {
//                player.setLooping(true);// 음악 반복 재생
//                player.start();         // 4. 재생 시작
//            }
//        });
//        player.prepareAsync();
    }


    public void stopMusic() { //음악 재생 중지
        Log.d(getClass().getSimpleName(), "stopMusic");
        if (mediaPlayer != null) {
            mediaPlayer.stop();     // 5. 재생 중지
            mediaPlayer.reset();
            mediaPlayer.release();    // 6. MediaPlayer 리소스 해제
            mediaPlayer = null;
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private String createNotificationChannel() { //채널 생성
        String channelId = "Alarm";
        String channelName = getString(R.string.app_name);
        NotificationChannel channel = new NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_NONE);
        //channel.setDescription(channelName);
        channel.setSound(null, null);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager.createNotificationChannel(channel);

        return channelId;
    }

    @Override
    public void onDestroy() { //서비스 끝날때 만들어주는 부분
        super.onDestroy();
        stopMusic();
//        audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
//        audio.setStreamVolume(AudioManager.STREAM_MUSIC, curvolume, 0); //알람 끝나면 다시 음량 이전으로 돌려줌
        Log.d("AlarmService", "Service onDestroy");

    }
//    private void startForegroundService() {
//        String channelId =  createNotificationChannel();
//        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channelId);
//        builder.setSmallIcon(R.mipmap.ic_launcher);
//        builder.setContentTitle("포그라운드 서비스");
//        builder.setContentText("포그라운드 서비스 실행 중");
//        Intent notificationIntent = new Intent(this, MainActivity.class);
//        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);
//        builder.setContentIntent(pendingIntent);
//
//        // 오레오에서는 알림 채널을 매니저에 생성해야 한다
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
//            manager.createNotificationChannel(new NotificationChannel("default", "기본 채널", NotificationManager.IMPORTANCE_DEFAULT));
//        }
//
//        // 포그라운드로 시작
//        startForeground(1, builder.build());
//    }
}